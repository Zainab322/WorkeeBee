import mongoose from 'mongoose';
import Review from '../models/Review.js';
import '../models/User.js';
// ✅ Submit a new review
export const createReview = async (req, res) => {
  console.log("📥 Incoming review data:", req.body);

  try {
    const { bookingId, customerId, providerId, rating, comment } = req.body;

    const review = await Review.create({
      bookingId,
      customerId,
      providerId,
      rating,
      comment
    });

    console.log("✅ Review created:", review);
    res.status(201).json(review);
  } catch (error) {
    console.error("❌ Error submitting review:", error.message);
    res.status(500).json({ message: 'Failed to submit review', error: error.message });
  }
};

// ✅ Get all reviews for a provider (newest first)
export const getProviderReviews = async (req, res) => {
  try {
    const { providerId } = req.params;

    const reviews = await Review.find({ providerId })
      .populate('customerId', 'name')
      .sort({ createdAt: -1 }); // Sort by newest first

    res.status(200).json(reviews);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch reviews', error: error.message });
  }
};

// ✅ Calculate average rating of a provider
export const getProviderAverageRating = async (req, res) => {
  try {
    const { providerId } = req.params;

    const result = await Review.aggregate([
      {
        $match: {
          providerId: new mongoose.Types.ObjectId(providerId)
        }
      },
      {
        $group: {
          _id: null,
          avgRating: { $avg: "$rating" }
        }
      }
    ]);

    const avgRating = result.length > 0
      ? Math.round(result[0].avgRating * 10) / 10  // Optional: round to 1 decimal
      : 0;

    res.status(200).json({ providerId, avgRating });
  } catch (error) {
    res.status(500).json({ message: 'Failed to calculate average rating', error: error.message });
  }
};
