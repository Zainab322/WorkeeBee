import express from 'express';
import { createReview, getProviderReviews, getProviderAverageRating } from '../controllers/reviewController.js';

const router = express.Router();

router.post('/', createReview);
router.get('/:providerId', getProviderReviews);
router.get('/:providerId/average', getProviderAverageRating);

export default router;
