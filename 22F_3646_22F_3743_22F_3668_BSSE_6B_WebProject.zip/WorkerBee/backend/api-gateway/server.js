import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import morgan from 'morgan';
import { createProxyMiddleware } from 'http-proxy-middleware';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 8000;

app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));

app.use(express.json());
app.use(morgan('dev'));

console.log("🚪 WorkerBee API Gateway initializing...");

const services = {
  '/api/auth': process.env.AUTH_SERVICE,
  '/api/bookings': process.env.BOOKING_SERVICE,
  '/api/complaints': process.env.COMPLAINT_SERVICE,
  '/api/providers': process.env.PROVIDER_SERVICE,
  '/api/reviews': process.env.REVIEW_SERVICE,
  '/api/favorites': process.env.FAVORITES_SERVICE,
};

Object.entries(services).forEach(([path, target]) => {
  if (!target) {
    console.error(`❌ Skipping ${path} — no target defined in .env`);
    return;
  }

  console.log(`🔁 Proxying ${path} → ${target}`);
  app.use(path, createProxyMiddleware({
    target,
    changeOrigin: true,
    credentials: true,
    onProxyReq: (proxyReq, req) => {

      if (
        req.body &&
        Object.keys(req.body).length &&
        !req.headers['content-type']?.includes('multipart/form-data')
      ) {
        const bodyData = JSON.stringify(req.body);
        proxyReq.setHeader('Content-Type', 'application/json');
        proxyReq.setHeader('Content-Length', Buffer.byteLength(bodyData));
        proxyReq.write(bodyData);
      }
    }
  }));
});

app.get('/', (req, res) => {
  res.send('🌐 WorkerBee API Gateway is running!');
});

app.listen(PORT, () => {
  console.log(`🚀 Gateway running at http://localhost:${PORT}`);
});
