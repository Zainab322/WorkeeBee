// routes/proxyRoutes.js
import express from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import dotenv from 'dotenv';

dotenv.config();
const router = express.Router();

const services = [
  { path: '/api/auth', target: process.env.AUTH_SERVICE },
  { path: '/api/bookings', target: process.env.BOOKING_SERVICE },
  { path: '/api/complaints', target: process.env.COMPLAINT_SERVICE },
  { path: '/api/providers', target: process.env.PROVIDER_SERVICE },
  { path: '/api/reviews', target: process.env.REVIEW_SERVICE },
  { path: '/api/favorites', target: process.env.FAVORITES_SERVICE },
];

services.forEach(({ path, target }) => {
  if (!target) {
    console.error(`❌ ERROR: Missing target for ${path}. Check your .env file.`);
    return;
  }

  console.log(`🔁 Setting up proxy: ${path} → ${target}`);

  router.use(path, (req, res, next) => {
    console.log(`➡️ Incoming request on gateway: ${req.method} ${req.originalUrl}`);
    next();
  });

  router.use(
    path,
    createProxyMiddleware({
      target,
      changeOrigin: true,
      selfHandleResponse: false,
      pathRewrite: (pathReq) => {
        console.log(`🧭 Path rewriting: ${pathReq} → ${pathReq}`);
        return pathReq;
      },
      onProxyReq: (proxyReq, req) => {
        console.log(`🛰 Forwarding to target: ${target}${req.url}`);

        if (req.body) {
          const bodyData = JSON.stringify(req.body);
          proxyReq.setHeader('Content-Type', 'application/json');
          proxyReq.setHeader('Content-Length', Buffer.byteLength(bodyData));
          proxyReq.write(bodyData);
        } else {
          let rawBody = '';
          req.on('data', chunk => rawBody += chunk);
          req.on('end', () => {
            if (rawBody) {
              proxyReq.setHeader('Content-Type', 'application/json');
              proxyReq.setHeader('Content-Length', Buffer.byteLength(rawBody));
              proxyReq.write(rawBody);
            }
          });
        }
      },
      onProxyRes: (proxyRes, req) => {
        console.log(`✅ Response from target for: ${req.method} ${req.originalUrl}`);
      },
      onError: (err, req, res) => {
        console.error(`❌ Proxy Error on ${req.originalUrl}:`, err.message);
        res.status(500).json({ message: 'Gateway Proxy Error', error: err.message });
      }
    })
  );
});

export default router;
