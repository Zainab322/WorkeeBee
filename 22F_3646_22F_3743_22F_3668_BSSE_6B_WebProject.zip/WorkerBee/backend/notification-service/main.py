from fastapi import FastAPI
from routers.notificationRoutes import router as notification_router
from database import connect_to_mongo

app = FastAPI()

# Connect to MongoDB
connect_to_mongo()

# Include Routes
app.include_router(notification_router, prefix="/api/notifications", tags=["Notifications"])
