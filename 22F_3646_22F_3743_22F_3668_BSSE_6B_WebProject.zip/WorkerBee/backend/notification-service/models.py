from pydantic import BaseModel

class Notification(BaseModel):
    userId: str
    message: str
    type: str
    isRead: bool = False
