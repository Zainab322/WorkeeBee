import motor.motor_asyncio
import os
from dotenv import load_dotenv

load_dotenv()

client = None
db = None

def connect_to_mongo():
    global client, db
    MONGO_URI = os.getenv("MONGO_URI")
    client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URI)
    db_name = MONGO_URI.split("/")[-1]  # Extract DB name from URI
    db = client[db_name]
