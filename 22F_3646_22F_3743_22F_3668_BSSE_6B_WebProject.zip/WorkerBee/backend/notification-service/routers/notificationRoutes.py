from fastapi import APIRouter, HTTPException
from models import Notification
from database import db
from bson import ObjectId

router = APIRouter()

@router.post("/")
async def create_notification(notification: Notification):
    notif_dict = notification.dict()
    result = await db.notifications.insert_one(notif_dict)
    if result.inserted_id:
        return { "message": "Notification created", "id": str(result.inserted_id) }
    raise HTTPException(status_code=400, detail="Notification creation failed")

@router.get("/{user_id}")
async def get_notifications(user_id: str):
    notifications_cursor = db.notifications.find({"userId": user_id})
    notifications = []
    async for notif in notifications_cursor:
        notif["_id"] = str(notif["_id"])
        notifications.append(notif)
    return notifications

@router.patch("/{notif_id}/read")
async def mark_notification_as_read(notif_id: str):
    result = await db.notifications.update_one(
        {"_id": ObjectId(notif_id)},
        {"$set": {"isRead": True}}
    )
    if result.modified_count == 1:
        return {"message": "Notification marked as read"}
    raise HTTPException(status_code=404, detail="Notification not found")
