import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import cors from 'cors';
import morgan from 'morgan';
import providerRoutes from './routes/providerRoutes.js';
import { setupSwaggerDocs } from './swagger.js';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5006;

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.use('/api/providers', providerRoutes);

// ✅ Swagger Docs
setupSwaggerDocs(app);

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('MongoDB connected');
    app.listen(PORT, () => {
      console.log(`Provider service running at http://localhost:${PORT}`);
      console.log(`Swagger docs at http://localhost:${PORT}/api-docs`);
    });
  })
  .catch((err) => console.error('Mongo connection failed:', err));
