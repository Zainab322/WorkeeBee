// swagger.js
import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Provider Service API',
      version: '1.0.0',
      description: 'API documentation for Provider Service',
    },
    servers: [
      {
        url: 'http://localhost:5006',
      },
    ],
  },
  apis: ['./routes/*.js'], // Path to the route files
};

const swaggerSpec = swaggerJsdoc(options);

export const setupSwaggerDocs = (app) => {
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
};
