import Provider from '../models/Provider.js';
import crypto from 'crypto';
import redisClient from '../redisClient.js';

const generateCacheKey = (filters) => {
  const hash = crypto.createHash('md5').update(JSON.stringify(filters)).digest('hex');
  return `providers:${hash}`;
};

export const getProviders = async (req, res) => {
  try {
    const filters = {};
    const { serviceType, area } = req.query;

    if (serviceType) filters.serviceType = serviceType;
    if (area) filters.area = area;

    if (!redisClient.isOpen) await redisClient.connect();

    const cacheKey = generateCacheKey(filters);
    const cachedData = await redisClient.get(cacheKey);

    if (cachedData) {
      console.log('📦 Redis hit for providers');
      return res.status(200).json(JSON.parse(cachedData));
    }

    const providers = await Provider.find(filters).sort({ createdAt: -1 });

    await redisClient.set(cacheKey, JSON.stringify(providers), { EX: 3600 });

    res.status(200).json(providers);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch providers', error: error.message });
  }
};

export const getProviderById = async (req, res) => {
  try {
    const provider = await Provider.findById(req.params.id);
    if (!provider) return res.status(404).json({ message: 'Provider not found' });
    res.status(200).json(provider);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching provider', error: error.message });
  }
};
