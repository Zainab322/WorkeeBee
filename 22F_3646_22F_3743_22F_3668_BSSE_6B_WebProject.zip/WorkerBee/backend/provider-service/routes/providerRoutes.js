import express from 'express';
import { getProviders, getProviderById } from '../controllers/providerController.js';

const router = express.Router();

/**
 * @swagger
 * /api/providers:
 *   get:
 *     summary: Get all providers
 *     description: Returns a list of all providers with optional filters.
 *     parameters:
 *       - in: query
 *         name: serviceType
 *         schema:
 *           type: string
 *         description: Filter by type of service
 *       - in: query
 *         name: area
 *         schema:
 *           type: string
 *         description: Filter by area
 *     responses:
 *       200:
 *         description: List of providers
 */
router.get('/', getProviders);

/**
 * @swagger
 * /api/providers/{id}:
 *   get:
 *     summary: Get provider by ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The provider ID
 *     responses:
 *       200:
 *         description: Provider found
 *       404:
 *         description: Provider not found
 */
router.get('/:id', getProviderById);

export default router;
