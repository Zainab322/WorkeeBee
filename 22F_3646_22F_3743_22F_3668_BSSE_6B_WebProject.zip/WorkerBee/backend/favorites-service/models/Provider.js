import mongoose from 'mongoose';

const providerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  phone: { type: String, required: true },
  cnic: { type: String },
  serviceType: { type: String, required: true },
  experience: { type: Number, default: 0 },
  area: { type: String },
  isVerified: { type: Boolean, default: false },
  rating: { type: Number, default: 0 },
  skills: [String],
  availability: [{
    day: String,
    timeSlots: [String]
  }]
}, { timestamps: true });

export default mongoose.model('Provider', providerSchema);
