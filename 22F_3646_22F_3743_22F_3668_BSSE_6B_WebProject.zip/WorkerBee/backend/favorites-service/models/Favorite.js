import mongoose from 'mongoose';

const favoriteSchema = new mongoose.Schema({
  customerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  providerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Provider', // ✅ This must match your `Provider` model name exactly
    required: true
  }
}, { timestamps: true });

export default mongoose.model('Favorite', favoriteSchema);
