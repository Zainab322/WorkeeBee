import express from 'express';
import { addFavorite, getFavorites, removeFavorite } from '../controllers/favoriteController.js';

const router = express.Router();

router.post('/', addFavorite);
router.get('/:customerId', getFavorites);
router.delete('/:customerId/:providerId', removeFavorite);

export default router;
