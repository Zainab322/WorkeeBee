import Favorite from '../models/Favorite.js';
import Provider from '../models/Provider.js'; // Ensure Provider model is registered

// ✅ Add a provider to favorites
export const addFavorite = async (req, res) => {
  try {
    const { customerId, providerId } = req.body;

    const existing = await Favorite.findOne({ customerId, providerId });
    if (existing) {
      return res.status(400).json({ message: 'Provider already in favorites' });
    }

    const favorite = await Favorite.create({ customerId, providerId });
    res.status(201).json(favorite);
  } catch (error) {
    res.status(500).json({ message: 'Failed to add favorite', error: error.message });
  }
};

// ✅ Get all favorites for a customer
export const getFavorites = async (req, res) => {
  try {
    const { customerId } = req.params;
    console.log("🔍 Fetching favorites for:", customerId);

    const favorites = await Favorite.find({ customerId })
      .populate('providerId', 'name serviceType area');

    console.log("✅ Favorites fetched:", favorites);
    res.status(200).json(favorites);
  } catch (error) {
    console.error("❌ Failed to fetch favorites:", error);
    res.status(500).json({ message: 'Failed to fetch favorites', error: error.message });
  }
};


// ✅ Remove a provider from favorites
export const removeFavorite = async (req, res) => {
  try {
    const { customerId, providerId } = req.params;
    const result = await Favorite.findOneAndDelete({ customerId, providerId });

    if (!result) {
      return res.status(404).json({ message: 'Favorite not found' });
    }

    res.status(200).json({ message: 'Favorite removed successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to remove favorite', error: error.message });
  }
};
