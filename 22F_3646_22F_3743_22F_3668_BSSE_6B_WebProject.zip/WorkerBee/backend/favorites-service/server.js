import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import connectDB from './config/db.js';
import favoriteRoutes from './routes/favoriteRoutes.js';

dotenv.config();
connectDB();

const app = express();

// ✅ Correct CORS setup
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));

app.use(express.json());
app.use('/api/favorites', favoriteRoutes);

const PORT = process.env.PORT || 5007;
app.listen(PORT, () => console.log(`🚀 Favorites Service running on port ${PORT}`));
