import User from '../models/User.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { OAuth2Client } from 'google-auth-library';

const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID); // ✅ Add this to .env

// ✅ Register Controller
export const register = async (req, res) => {
  try {
    console.log("✅ Reached register controller");

    const {
      name,
      email,
      password,
      role,
      phone,
      serviceType,
      city,
      experience
    } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const certificates = req.files?.map(file => file.path) || [];

    const userData = {
      name,
      email,
      phone,
      password: hashedPassword,
      role,
      certificates
    };

    if (role === 'provider') {
      userData.serviceType = serviceType;
      userData.city = city;
      userData.experience = experience;
    }

    const user = await User.create(userData);

    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({ token, user });

  } catch (error) {
    console.error("❌ Registration Error:", error);
    res.status(500).json({ message: 'Failed to register', error: error.message });
  }
};

// ✅ Login Controller
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user || !user.password) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(200).json({ token, user });
  } catch (error) {
    res.status(500).json({ message: 'Failed to login', error: error.message });
  }
};

// ✅ Google Login Controller
export const googleLogin = async (req, res) => {
  try {
    const { credential } = req.body;
    const ticket = await client.verifyIdToken({
      idToken: credential,
      audience: process.env.GOOGLE_CLIENT_ID,
    });

    const payload = ticket.getPayload();
    const { email, name, picture } = payload;

    let user = await User.findOne({ email });

    if (!user) {
      user = await User.create({
        name,
        email,
        profilePicture: picture,
        role: 'customer', // default role
      });
    }

    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.status(200).json({ token, user });

  } catch (error) {
    console.error('❌ Google login error:', error);
    res.status(401).json({ message: 'Invalid Google token', error: error.message });
  }
};

// ✅ (Optional) Callback if you're using redirect flow (not used in OneTap)
export const googleAuthCallback = (req, res) => {
  try {
    const user = req.user;
    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );
    res.redirect(`http://localhost:3000/google-success?token=${token}`);
  } catch (error) {
    res.status(500).json({ message: 'Google authentication failed', error: error.message });
  }
};
