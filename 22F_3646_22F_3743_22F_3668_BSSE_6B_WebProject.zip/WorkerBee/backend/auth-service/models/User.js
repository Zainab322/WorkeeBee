import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String },
  phone: { type: String }, // ✅ Added
  role: { type: String, enum: ['customer', 'provider', 'admin'], default: 'customer' },
  serviceType: { type: String }, // ✅ Provider-specific
  city: { type: String },         // ✅ Provider-specific
  experience: { type: Number },   // ✅ Provider-specific
  googleId: { type: String },
  certificates: [{ type: String }],
  profilePicture: { type: String }
}, { timestamps: true });


export default mongoose.model('User', userSchema);
