import express from 'express';
import passport from 'passport';
import upload from '../middlewares/upload.js';
import { register, login, googleAuthCallback, googleLogin} from '../controllers/authController.js';
import { protect } from '../middlewares/authMiddleware.js'; // ✅ add this

const router = express.Router();

router.post('/register', upload.array('certificates'), register);
router.post('/login', login);
router.post('/google-login', googleLogin); // Add this in routes/authRoutes.js

// ✅ Token validation route
router.get('/validate', protect, (req, res) => {
  res.status(200).json({
    user: req.user,
    token: req.token
  });
});

router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));
router.get('/google/callback', passport.authenticate('google', { session: false }), googleAuthCallback);

export default router;
