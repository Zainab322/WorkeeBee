import Booking from '../models/Booking.js';
import User from '../models/User.js';
import moment from 'moment';

export const createBooking = async (req, res) => {
    try {
      const { customerId, providerId, date, timeSlot, address, notes } = req.body;
  
      const existingBooking = await Booking.findOne({
        providerId,
        date,
        timeSlot,
        status: { $in: ['Pending', 'Accepted'] }
      });
  
      if (existingBooking) {
        const provider = await User.findById(providerId);
        return res.status(409).json({
          message: `Sorry! ${provider.name} is already booked at this time slot.`,
          providerDetails: {
            name: provider.name,
            serviceType: provider.serviceType
          }
        });
      }
      
      const alreadyBooked = await Booking.findOne({
        customerId,
        providerId,
        date,
        timeSlot
      });
  
      if (alreadyBooked) {
        return res.status(409).json({ message: "You already booked this provider at this time" });
      }
  
      const booking = new Booking({
        customerId,
        providerId,
        date,
        timeSlot,
        address,
        notes
      });
  
      await booking.save();
      res.status(201).json({ message: "Booking created", booking });
    } catch (err) {
      res.status(500).json({ message: "Failed to create booking", error: err.message });
    }
};  

export const getProviderBookings = async (req, res) => {
  try {
    const providerId = req.params.id;
    const bookings = await Booking.find({ providerId }).populate('customerId', 'name email');
    res.status(200).json(bookings);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch bookings", error: err.message });
  }
};

export const updateBookingStatus = async (req, res) => {
  try {
    const { bookingId } = req.params;
    const { status } = req.body;

    const booking = await Booking.findById(bookingId);
    if (!booking) return res.status(404).json({ message: "Booking not found" });

    booking.status = status;
    await booking.save();

    res.status(200).json({ message: "Booking status updated", booking });
  } catch (err) {
    res.status(500).json({ message: "Failed to update booking", error: err.message });
  }
};

export const getCustomerBookings = async (req, res) => {
    try {
      const customerId = req.params.id;
      const bookings = await Booking.find({ customerId }).populate('providerId', 'name serviceType');
  
      const enriched = bookings.map((b) => {
        const bookingTime = moment(`${b.date} ${b.timeSlot.split('-')[0]}`, 'YYYY-MM-DD h:mmA');
        const hoursLeft = bookingTime.diff(moment(), 'hours');
        return {
          ...b._doc,
          isCancelable: hoursLeft >= 2
        };
      });
  
      res.status(200).json(enriched);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch bookings", error: err.message });
    }
};

export const cancelBooking = async (req, res) => {
  try {
    const { bookingId } = req.params;
    const booking = await Booking.findById(bookingId)
      .populate('providerId', 'name email')
      .populate('customerId', 'name email');

    if (!booking) return res.status(404).json({ message: "Booking not found" });

    if (booking.status === 'Completed') {
      return res.status(400).json({ message: "Cannot cancel a completed booking" });
    }

    booking.status = 'Cancelled';
    await booking.save();

    console.log(`📩 Email to ${booking.providerId.email}: 
    "Hello ${booking.providerId.name}, your booking on ${booking.date} has been cancelled by the customer."`);

    console.log(`📩 Email to ${booking.customerId.email}: 
    "Hi ${booking.customerId.name}, your booking has been successfully cancelled."`);

    res.status(200).json({ message: "Booking cancelled", booking });
  } catch (err) {
    res.status(500).json({ message: "Failed to cancel booking", error: err.message });
  }
};

export const getCustomerBookingHistory = async (req, res) => {
  try {
    const { customerId } = req.params;
    const { status } = req.query;

    const filter = {
      customerId,
      status: status
        ? status 
        : { $in: ["Completed", "Cancelled", "Cancelled (Admin)"] } 
    };

    const history = await Booking.find(filter).populate("providerId", "name serviceType");

    res.status(200).json(history);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch booking history", error: err.message });
  }
};

  