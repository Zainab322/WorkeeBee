import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  phone: {
    type: String,
    required: true,
    trim: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: ['customer', 'provider', 'admin'],
    default: 'customer'
  },

  cnic: {
    type: String,
    trim: true
  },
  serviceType: {
    type: String,
    trim: true
  },
  certificates: [{
    type: String 
  }],
  experience: {
    type: Number,
    min: 0
  },
  skills: [{
    type: String,
    trim: true
  }],
  location: {
    type: String,
    trim: true
  },
  availability: [{
    day: {
      type: String,
      enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    },
    timeSlots: [{
      type: String
    }]
  }],
  profilePicture: {
    type: String 
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  profileCompletion: {
    type: Number,
    default: 0 
  },

  
  favorites: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }]
}, {
  timestamps: true
});

export default mongoose.model('User', userSchema);
