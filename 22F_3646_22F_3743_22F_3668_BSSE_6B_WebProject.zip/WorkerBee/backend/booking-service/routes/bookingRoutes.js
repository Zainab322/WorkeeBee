import express from 'express';
import {
  createBooking,
  getProviderBookings,
  getCustomerBookings,
  updateBookingStatus,
  cancelBooking
} from '../controllers/bookingController.js';

import { protect, authorizeRoles } from '../middleware/authMiddleware.js';
import { getCustomerBookingHistory } from '../controllers/bookingController.js';

const router = express.Router();

router.post('/', protect, authorizeRoles('customer'), createBooking);
router.get('/provider/:id', protect, authorizeRoles('provider'), getProviderBookings);
router.get('/customer/:id', protect, authorizeRoles('customer'), getCustomerBookings);
router.put('/:bookingId/status', protect, authorizeRoles('provider', 'admin'), updateBookingStatus);
router.put('/:bookingId/cancel', protect, authorizeRoles('customer', 'admin'), cancelBooking);
router.get('/history/:customerId', protect, authorizeRoles('customer'), getCustomerBookingHistory);

export default router;
