import Complaint from '../models/Complaint.js';
import '../models/User.js';
// Submit a new complaint
export const submitComplaint = async (req, res) => {
  try {
    const { userId, againstId, message, severity } = req.body;

    const complaint = await Complaint.create({ userId, againstId, message, severity });
    res.status(201).json(complaint);
  } catch (error) {
    res.status(500).json({ message: 'Failed to submit complaint', error: error.message });
  }
};

// Get complaints for admin
export const getAllComplaints = async (req, res) => {
  try {
    const complaints = await Complaint.find()
      .populate('userId', 'name')
      .populate('againstId', 'name')
      .sort({ createdAt: -1 });

    res.status(200).json(complaints);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch complaints', error: error.message });
  }
};

// Update complaint status
export const updateComplaintStatus = async (req, res) => {
  try {
    const { complaintId } = req.params;
    const { status } = req.body;

    const updated = await Complaint.findByIdAndUpdate(complaintId, { status }, { new: true });

    res.status(200).json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update complaint', error: error.message });
  }
};
