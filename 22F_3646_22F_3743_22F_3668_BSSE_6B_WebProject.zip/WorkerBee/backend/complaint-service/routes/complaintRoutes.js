import express from 'express';
import {
  submitComplaint,
  getAllComplaints,
  updateComplaintStatus
} from '../controllers/complaintController.js';

const router = express.Router();

router.post('/', submitComplaint); // Anyone can complain
router.get('/', getAllComplaints); // Admin view
router.put('/:complaintId', updateComplaintStatus); // Admin resolves

export default router;
