import { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../utils/axiosInstance';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // Validate token on initial load
  useEffect(() => {
    const validateToken = async () => {
      try {
        if (token) {
          const response = await axios.get('/api/auth/validate', {
            headers: { Authorization: `Bearer ${token}` },
          });
          setUser(response.data.user);
          localStorage.setItem('token', response.data.token);
          setToken(response.data.token);
        }
      } catch (error) {
        logout();
      } finally {
        setLoading(false);
      }
    };

    validateToken();
  }, [token]);

  // Email/Password login
  const login = async (credentials) => {
    try {
      const response = await axios.post('/api/auth/login', credentials, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
  
      const { user, token } = response.data;
  
      // ✅ Store user and token in state and localStorage
      setUser(user);
      setToken(token);
      localStorage.setItem('token', token);
  
      return { success: true, user }; // ✅ Return user object
    } catch (error) {
      console.error("❌ Login error:", error.response?.data || error.message);
      const message = error.response?.data?.message || 'Login failed';
      return { success: false, message };
    }
  };
  

  // Google login using token from Google and server verification
  const googleLogin = async (credential) => {
    try {
      const response = await axios.post('/api/auth/google-login', { credential });
      setUser(response.data.user);
      setToken(response.data.token);
      localStorage.setItem('token', response.data.token);
      return { success: true };
    } catch (error) {
      const message = error.response?.data?.message || 'Google login failed';
      return { success: false, message };
    }
  };

  const register = async (userData) => {
    try {
      const response = await axios.post('/api/auth/register', userData);
      setUser(response.data.user);
      setToken(response.data.token);
      localStorage.setItem('token', response.data.token);
      return { success: true };
    } catch (error) {
      return { success: false, message: error.response?.data?.message || 'Registration failed' };
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('token');
    navigate('/');
  };

  return (
    <AuthContext.Provider value={{ user, token, login, register, googleLogin, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
