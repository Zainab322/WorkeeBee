// src/components/admin/BookingTable.jsx

import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Box,
  Typography
} from '@mui/material';

const BookingTable = ({ bookings }) => (
  <TableContainer component={Paper}>
    <Table>
      <TableHead>
        <TableRow>
          <TableCell>Booking ID</TableCell>
          <TableCell>Customer</TableCell>
          <TableCell>Provider</TableCell>
          <TableCell>Service</TableCell>
          <TableCell>Date</TableCell>
          <TableCell>Status</TableCell>
          <TableCell>Action</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {bookings.length === 0 ? (
          <TableRow>
            <TableCell colSpan={7} align="center">
              <Box sx={{ py: 3 }}>
                <Typography>No bookings found.</Typography>
              </Box>
            </TableCell>
          </TableRow>
        ) : (
          bookings.map((booking) => (
            <TableRow key={booking.id}>
              <TableCell>{booking.id}</TableCell>
              <TableCell>{booking.customerName}</TableCell>
              <TableCell>{booking.providerName}</TableCell>
              <TableCell>{booking.serviceType}</TableCell>
              <TableCell>{booking.date} at {booking.time}</TableCell>
              <TableCell>{booking.status}</TableCell>
              <TableCell>
                {booking.status === 'Confirmed' && (
                  <Button
                    variant="outlined"
                    color="error"
                    size="small"
                    onClick={() => alert('Cancel logic here')}
                  >
                    Cancel
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  </TableContainer>
);

export default BookingTable;
