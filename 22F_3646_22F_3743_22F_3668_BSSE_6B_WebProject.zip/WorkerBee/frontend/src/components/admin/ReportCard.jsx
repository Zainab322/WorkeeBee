import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';

const ReportCard = ({ title, items }) => (
  <Card>
    <CardContent>
      <Typography variant="h6" gutterBottom>{title}</Typography>
      {items.map((line, index) => (
        <Typography key={index}>{line}</Typography>
      ))}
    </CardContent>
  </Card>
);

export default ReportCard;
