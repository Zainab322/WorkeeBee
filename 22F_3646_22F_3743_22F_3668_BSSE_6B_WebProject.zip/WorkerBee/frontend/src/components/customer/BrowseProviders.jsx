import React, { useState } from 'react';
import { Box, Button, Card, CardContent, Grid, TextField, Typography, Select, MenuItem, FormControl, InputLabel, Slider, Checkbox, FormGroup, FormControlLabel, Pagination } from '@mui/material';
import ProviderCard from '../../components/customer/ProviderCard';
import FilterAltIcon from '@mui/icons-material/FilterAlt';

const BrowseProviders = () => {
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [page, setPage] = useState(1);
  
  // Mock data - replace with actual API data
  const providers = [
    {
      id: 1,
      name: 'Aisha Khan',
      serviceType: 'Cook',
      rating: 4.8,
      reviews: 42,
      experience: 5,
      city: 'Karachi',
      hourlyRate: 500,
      available: true,
      image: '/path/to/image.jpg',
    },
    {
      id: 2,
      name: 'Ali Ahmed',
      serviceType: 'Plumber',
      rating: 4.5,
      reviews: 28,
      experience: 7,
      city: 'Lahore',
      hourlyRate: 600,
      available: true,
      image: '/path/to/image.jpg',
    },
    // Add more providers as needed
  ];

  const serviceTypes = ['Cook', 'Plumber', 'Electrician', 'Maid', 'Babysitter', 'Driver'];
  const cities = ['Karachi', 'Lahore', 'Islamabad', 'Rawalpindi', 'Faisalabad'];

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 700 }}>
        Browse Service Providers
      </Typography>

      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <TextField
          variant="outlined"
          placeholder="Search by name, skill or location"
          sx={{ width: '60%' }}
        />
        <Button
          variant="outlined"
          startIcon={<FilterAltIcon />}
          onClick={() => setFiltersOpen(!filtersOpen)}
        >
          Filters
        </Button>
      </Box>

      {filtersOpen && (
        <Card sx={{ mb: 3, p: 2 }}>
          <CardContent>
            <Grid container spacing={3}>
              <Grid item xs={12} md={4}>
                <FormControl fullWidth>
                  <InputLabel>Service Type</InputLabel>
                  <Select multiple label="Service Type">
                    {serviceTypes.map((type) => (
                      <MenuItem key={type} value={type}>
                        {type}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={4}>
                <FormControl fullWidth>
                  <InputLabel>City</InputLabel>
                  <Select multiple label="City">
                    {cities.map((city) => (
                      <MenuItem key={city} value={city}>
                        {city}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={4}>
                <Typography gutterBottom>Rating</Typography>
                <Slider
                  value={[3, 5]}
                  min={0}
                  max={5}
                  step={0.1}
                  valueLabelDisplay="auto"
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <Typography gutterBottom>Hourly Rate (PKR)</Typography>
                <Slider
                  value={[300, 1000]}
                  min={100}
                  max={2000}
                  step={50}
                  valueLabelDisplay="auto"
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <FormGroup>
                  <FormControlLabel control={<Checkbox />} label="Available Now" />
                  <FormControlLabel control={<Checkbox />} label="Verified Providers" />
                </FormGroup>
              </Grid>
              <Grid item xs={12} md={4}>
                <Button variant="contained" fullWidth>
                  Apply Filters
                </Button>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      )}

      <Grid container spacing={3}>
        {providers.map((provider) => (
          <Grid item xs={12} sm={6} md={4} key={provider.id}>
            <ProviderCard provider={provider} />
          </Grid>
        ))}
      </Grid>

      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <Pagination
          count={5}
          page={page}
          onChange={(event, value) => setPage(value)}
          color="primary"
        />
      </Box>
    </Box>
  );
};

export default BrowseProviders;