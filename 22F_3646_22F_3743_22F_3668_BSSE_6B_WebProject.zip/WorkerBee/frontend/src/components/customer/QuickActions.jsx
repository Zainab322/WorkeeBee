import React from 'react';
import { Box, Button, Grid, Typography } from '@mui/material';

const QuickActions = ({ navigate }) => {
  return (
    <Box sx={{ mb: 4 }}>
      <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
        Quick Actions
      </Typography>
      <Grid container spacing={2}>
        <Grid item xs={6} sm={3}>
          <Button
            fullWidth
            variant="contained"
            onClick={() => navigate('/customer/browse')}
            sx={{ py: 2 }}
          >
            Book a Provider
          </Button>
        </Grid>
        <Grid item xs={6} sm={3}>
          <Button
            fullWidth
            variant="outlined"
            onClick={() => navigate('/customer/favorites')}
            sx={{ py: 2 }}
          >
            View Favorites
          </Button>
        </Grid>
        <Grid item xs={6} sm={3}>
          <Button
            fullWidth
            variant="outlined"
            onClick={() => navigate('/customer/history')}
            sx={{ py: 2 }}
          >
            Booking History
          </Button>
        </Grid>
        <Grid item xs={6} sm={3}>
          <Button
            fullWidth
            variant="outlined"
            onClick={() => navigate('/customer/profile')}
            sx={{ py: 2 }}
          >
            My Profile
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
};

export default QuickActions;