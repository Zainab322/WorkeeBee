import React from 'react';
import { useNavigate } from 'react-router-dom';
import './CustomerDashboard.css';

const CustomerDashboard = () => {
  const navigate = useNavigate();

  return (
    <div className="dashboard-container">
      <h2>Welcome to WorkerBee 👋</h2>
      <p className="sub-heading">Manage your services and bookings effortlessly</p>

      <div className="dashboard-buttons">
        <button onClick={() => navigate('/customer/browse')} className="btn">Book a Provider</button>
        <button onClick={() => navigate('/customer/favorites')} className="btn">View Favorites</button>
        <button onClick={() => navigate('/customer/history')} className="btn">Booking History</button>
      </div>

      <div className="recent-bookings">
        <h3>Recent Bookings</h3>
        <ul>
          <li>🧹 Maid - May 10, 2025</li>
          <li>👨‍🔧 Electrician - May 5, 2025</li>
          <li>👩‍🍳 Cook - April 28, 2025</li>
        </ul>
      </div>
    </div>
  );
};

export default CustomerDashboard;
