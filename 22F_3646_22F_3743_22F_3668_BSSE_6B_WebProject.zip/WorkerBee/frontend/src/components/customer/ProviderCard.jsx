import React from 'react';
import { Card, CardContent, Typography, Box, Button, Rating, Chip } from '@mui/material';
import WorkIcon from '@mui/icons-material/Work';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import { useNavigate } from 'react-router-dom';

const ProviderCard = ({ provider }) => {
  const navigate = useNavigate();

  if (!provider) return null;

  return (
    <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <CardContent>
        <Box sx={{ mb: 2 }}>
          <Typography variant="h6">{provider.name || 'Unnamed'}</Typography>
          <Typography variant="body2" color="text.secondary">{provider.serviceType || 'N/A'}</Typography>
        </Box>

        <Box sx={{ mb: 1 }}>
          <Chip icon={<LocationOnIcon />} label={provider.area || 'N/A'} sx={{ mr: 1 }} />
          <Chip icon={<WorkIcon />} label={`${provider.experience ?? 0} yrs experience`} />
        </Box>

        {provider.rating && (
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <Rating value={provider.rating} precision={0.5} readOnly />
            <Typography variant="body2" sx={{ ml: 1 }}>
              {provider.rating.toFixed(1)}
            </Typography>
          </Box>
        )}

        {provider.skills && provider.skills.length > 0 && (
          <Box sx={{ mt: 1 }}>
            {provider.skills.map((skill, idx) => (
              <Chip key={idx} label={skill} variant="outlined" sx={{ mr: 1, mb: 1 }} />
            ))}
          </Box>
        )}
      </CardContent>

      <Box sx={{ p: 2, pt: 0 }}>
        <Button
          fullWidth
          variant="contained"
          onClick={() => navigate(`/customer/booking/${provider._id}`)}
        >
          Book Now
        </Button>
      </Box>
    </Card>
  );
};

export default ProviderCard;
