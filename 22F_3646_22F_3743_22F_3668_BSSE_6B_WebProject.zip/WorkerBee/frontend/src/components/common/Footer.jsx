import React from 'react';
import { Box, Container, Grid, Link, Typography } from '@mui/material';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import InstagramIcon from '@mui/icons-material/Instagram';
import LinkedInIcon from '@mui/icons-material/LinkedIn';

const Footer = () => {
  return (
    <Box
      component="footer"
      sx={{
        backgroundColor: 'background.paper',
        py: 6,
        borderTop: '1px solid',
        borderColor: 'divider',
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          <Grid item xs={12} md={4}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 700 }}>
              WorkerBee
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Connecting you with trusted service providers for all your household needs.
            </Typography>
            <Box sx={{ mt: 2, display: 'flex', gap: 2 }}>
              <Link href="#" color="inherit">
                <FacebookIcon />
              </Link>
              <Link href="#" color="inherit">
                <TwitterIcon />
              </Link>
              <Link href="#" color="inherit">
                <InstagramIcon />
              </Link>
              <Link href="#" color="inherit">
                <LinkedInIcon />
              </Link>
            </Box>
          </Grid>

          <Grid item xs={6} md={2}>
            <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 600 }}>
              Company
            </Typography>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>
              About Us
            </Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>
              Careers
            </Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>
              Blog
            </Link>
          </Grid>

          <Grid item xs={6} md={2}>
            <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 600 }}>
              Support
            </Typography>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>
              Help Center
            </Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>
              Safety
            </Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>
              FAQs
            </Link>
          </Grid>

          <Grid item xs={6} md={2}>
            <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 600 }}>
              Legal
            </Typography>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>
              Terms
            </Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>
              Privacy
            </Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>
              Cookies
            </Link>
          </Grid>

          <Grid item xs={6} md={2}>
            <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 600 }}>
              Contact
            </Typography>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              info@workerbee.com
            </Typography>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              +92 300 1234567
            </Typography>
          </Grid>
        </Grid>

        <Box sx={{ mt: 4, pt: 4, borderTop: '1px solid', borderColor: 'divider' }}>
          <Typography variant="body2" color="text.secondary" align="center">
            © {new Date().getFullYear()} WorkerBee. All rights reserved.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
};

export default Footer;