import React from 'react';
import { Box, Card, CardContent, Typography } from '@mui/material';

const StatsCard = ({ title, value, icon, change, isStat }) => {
  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Typography variant="subtitle1" color="text.secondary" gutterBottom>
            {title}
          </Typography>
          <Typography variant="h5">{icon}</Typography>
        </Box>
        <Typography variant="h4" component="div" sx={{ fontWeight: 700 }}>
          {value}
        </Typography>
        {isStat && change && (
          <Typography variant="body2" color={change.startsWith('+') ? 'success.main' : 'error.main'}>
            {change} from last month
          </Typography>
        )}
      </CardContent>
    </Card>
  );
};

export default StatsCard;