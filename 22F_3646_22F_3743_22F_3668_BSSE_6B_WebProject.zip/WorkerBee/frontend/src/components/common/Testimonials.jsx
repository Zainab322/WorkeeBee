import React from 'react';
import { Box, Typography, Avatar, Container } from '@mui/material';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const testimonials = [
  {
    id: 1,
    name: 'Sarah Johnson',
    role: 'Homeowner',
    content: 'WorkerBee saved me so much time finding a reliable babysitter. The platform is easy to use and all providers are verified.',
    avatar: 'SJ',
  },
  {
    id: 2,
    name: 'Michael Chen',
    role: 'Restaurant Owner',
    content: 'As a small business owner, I use WorkerBee to find temporary cooks. The quality of professionals is consistently high.',
    avatar: 'MC',
  },
  {
    id: 3,
    name: 'Aisha Rahman',
    role: 'Service Provider',
    content: 'Since joining WorkerBee, I\'ve been able to grow my cleaning business significantly. The platform connects me with great clients.',
    avatar: 'AR',
  },
];

const Testimonials = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
  };

  return (
    <Box sx={{ maxWidth: 800, mx: 'auto', px: 2 }}>
      <Slider {...settings}>
        {testimonials.map((testimonial) => (
          <Box key={testimonial.id} sx={{ px: 4, textAlign: 'center' }}>
            <Typography variant="body1" sx={{ fontStyle: 'italic', mb: 3 }}>
              "{testimonial.content}"
            </Typography>
            <Avatar sx={{ width: 56, height: 56, mx: 'auto', mb: 2 }}>
              {testimonial.avatar}
            </Avatar>
            <Typography variant="h6" component="h3">
              {testimonial.name}
            </Typography>
            <Typography variant="subtitle2" color="text.secondary">
              {testimonial.role}
            </Typography>
          </Box>
        ))}
      </Slider>
    </Box>
  );
};

export default Testimonials;