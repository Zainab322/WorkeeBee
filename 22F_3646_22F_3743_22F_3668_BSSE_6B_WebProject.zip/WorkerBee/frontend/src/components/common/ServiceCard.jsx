import { Card, CardContent, Typography, Box } from '@mui/material';

const ServiceCard = ({ service }) => {
  return (
    <Card sx={{ 
      height: '100%', 
      display: 'flex', 
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      transition: 'transform 0.3s',
      '&:hover': {
        transform: 'scale(1.05)',
        boxShadow: 6,
      },
    }}>
      <CardContent>
        <Box sx={{ fontSize: '3rem', mb: 2 }}>{service.icon}</Box>
        <Typography variant="h6" component="h3" gutterBottom>
          {service.name}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default ServiceCard;