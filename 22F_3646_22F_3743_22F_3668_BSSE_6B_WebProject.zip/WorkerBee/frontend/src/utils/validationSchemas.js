import * as yup from 'yup';

export const loginSchema = yup.object({
  email: yup.string().email('Enter a valid email').required('Email is required'),
  password: yup.string().required('Password is required'),
});

export const customerRegistrationSchema = yup.object({
  name: yup.string().required('Name is required'),
  email: yup.string().email('Enter a valid email').required('Email is required'),
  phone: yup.string().required('Phone number is required'),
  password: yup.string().min(8, 'Password should be at least 8 characters').required('Password is required'),
  confirmPassword: yup.string()
    .oneOf([yup.ref('password'), null], 'Passwords must match')
    .required('Confirm Password is required'),
});

export const providerRegistrationSchema = yup.object({
  name: yup.string().required('Name is required'),
  email: yup.string().email('Enter a valid email').required('Email is required'),
  phone: yup.string().required('Phone number is required'),
  password: yup.string().min(8, 'Password should be at least 8 characters').required('Password is required'),
  confirmPassword: yup.string()
    .oneOf([yup.ref('password'), null], 'Passwords must match')
    .required('Confirm Password is required'),
  serviceType: yup.string().required('Service type is required'),
  city: yup.string().required('City is required'),
  experience: yup.number().required('Experience is required').min(0, 'Experience cannot be negative'),
  cnic: yup.string().required('CNIC is required'),
});

export const bookingSchema = yup.object({
  date: yup.date().required('Date is required'),
  time: yup.string().required('Time is required'),
  address: yup.string().required('Address is required'),
  instructions: yup.string(),
});