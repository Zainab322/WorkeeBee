import axios from 'axios';

const API_URL = '/api/providers';

const getProviders = async (filters) => {
  const response = await axios.get(API_URL, { params: filters });
  return response.data;
};

const getProvider = async (providerId) => {
  const response = await axios.get(`${API_URL}/${providerId}`);
  return response.data;
};

const getJobRequests = async (providerId) => {
  const response = await axios.get(`${API_URL}/${providerId}/jobs`);
  return response.data;
};

const respondToJob = async (providerId, jobId, action) => {
  const response = await axios.put(`${API_URL}/${providerId}/jobs/${jobId}`, { action });
  return response.data;
};

export default {
  getProviders,
  getProvider,
  getJobRequests,
  respondToJob,
};