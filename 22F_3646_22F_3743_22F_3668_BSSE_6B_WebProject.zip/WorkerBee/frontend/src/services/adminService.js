import axios from 'axios';

const API_URL = '/api/admin';

const getPendingProviders = async () => {
  const response = await axios.get(`${API_URL}/providers/pending`);
  return response.data;
};

const verifyProvider = async (providerId, action) => {
  const response = await axios.put(`${API_URL}/providers/${providerId}/verify`, { action });
  return response.data;
};

const getUsers = async (filters) => {
  const response = await axios.get(`${API_URL}/users`, { params: filters });
  return response.data;
};

const updateUserStatus = async (userId, status) => {
  const response = await axios.put(`${API_URL}/users/${userId}/status`, { status });
  return response.data;
};

const getReports = async (filters) => {
  const response = await axios.get(`${API_URL}/reports`, { params: filters });
  return response.data;
};

const updateReportStatus = async (reportId, status) => {
  const response = await axios.put(`${API_URL}/reports/${reportId}/status`, { status });
  return response.data;
};

const getAnalytics = async () => {
  const response = await axios.get(`${API_URL}/analytics`);
  return response.data;
};

export default {
  getPendingProviders,
  verifyProvider,
  getUsers,
  updateUserStatus,
  getReports,
  updateReportStatus,
  getAnalytics,
};