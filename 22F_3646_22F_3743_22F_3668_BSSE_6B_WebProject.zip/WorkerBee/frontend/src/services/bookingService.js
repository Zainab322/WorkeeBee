import axios from 'axios';

const API_URL = '/api/bookings';

const createBooking = async (bookingData) => {
  const response = await axios.post(API_URL, bookingData);
  return response.data;
};

const getBookings = async (userId, role) => {
  const response = await axios.get(`${API_URL}/${role}/${userId}`);
  return response.data;
};

const cancelBooking = async (bookingId) => {
  const response = await axios.put(`${API_URL}/${bookingId}/cancel`);
  return response.data;
};

export default {
  createBooking,
  getBookings,
  cancelBooking,
};