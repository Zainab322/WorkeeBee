import axios from 'axios';

const API_URL = '/api/auth';

const register = async (userData) => {
  const response = await axios.post(`${API_URL}/register`, userData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
  return response.data;
};

const login = async (credentials) => {
  const response = await axios.post(`${API_URL}/login`, credentials);
  return response.data;
};

const logout = async () => {
  const response = await axios.post(`${API_URL}/logout`);
  return response.data;
};

const validateToken = async (token) => {
  const response = await axios.get(`${API_URL}/validate`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
};

export default {
  register,
  login,
  logout,
  validateToken,
};