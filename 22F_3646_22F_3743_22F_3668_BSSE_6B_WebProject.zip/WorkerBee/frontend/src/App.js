import React from 'react';
import { Routes, Route } from 'react-router-dom';

import Layout from './components/common/Layout';
import HomePage from './pages/shared/HomePage';
import LandingPage from './pages/shared/LandingPage';
import RoleSelection from './pages/auth/RoleSelection';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';

import CustomerDashboard from './pages/customer/CustomerDashboard';
import BrowseProviders from './pages/customer/BrowseProviders';
import ProviderProfile from './pages/shared/ProviderProfile';
import BookingPage from './pages/customer/BookingPage';
import FavoritesPage from './pages/customer/FavoritesPage';
import BookingHistory from './pages/customer/BookingHistory';

import ProviderDashboard from './pages/provider/Dashboard';
import ProviderProfileSetup from './pages/provider/ProfileSetup';
import JobRequests from './pages/provider/JobRequests';
import PaymentReviews from './pages/provider/PaymentReviews';

import AdminDashboard from './pages/admin/AdminDashboard';
import VerifyProviders from './pages/admin/Providers';
import ManageUsers from './pages/admin/Users';
import ManageBookings from './pages/admin/Bookings';
import ComplaintsReports from './pages/admin/ComplaintsReports';
import AnalyticsReports from './pages/admin/AnalyticsReports';

import NotFound from './pages/shared/NotFound';
import RoleRoute from './utils/RoleRoute'; // ✅ role-based route guard
import AboutUs from './pages/shared/AboutUs';
function App() {
  return (
    <Routes>
      {/* 🌐 Public Route */}
      <Route path="/landing" element={<LandingPage />} />

      {/* 🧱 All other routes are inside the main layout */}
      <Route path="/" element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="role-selection" element={<RoleSelection />} />
        <Route path="login" element={<Login />} />
        <Route path="register" element={<Register />} />
        <Route path="/about" element={<AboutUs />} />
        {/* 👤 Customer Routes (Protected) */}
        <Route
          path="customer/dashboard"
          element={<RoleRoute allowedRoles={['customer']} element={<CustomerDashboard />} />}
        />
        <Route
          path="customer/browse"
          element={<RoleRoute allowedRoles={['customer']} element={<BrowseProviders />} />}
        />
        <Route
          path="customer/provider/:id"
          element={<RoleRoute allowedRoles={['customer']} element={<ProviderProfile />} />}
        />
        <Route
          path="customer/booking/:id"
          element={<RoleRoute allowedRoles={['customer']} element={<BookingPage />} />}
        />
        <Route
          path="customer/favorites"
          element={<RoleRoute allowedRoles={['customer']} element={<FavoritesPage />} />}
        />
        <Route
          path="customer/history"
          element={<RoleRoute allowedRoles={['customer']} element={<BookingHistory />} />}
        />

        {/* 🧑‍🔧 Provider Routes (Protected) */}
        <Route
          path="provider/dashboard"
          element={<RoleRoute allowedRoles={['provider']} element={<ProviderDashboard />} />}
        />
        <Route
          path="provider/profile-setup"
          element={<RoleRoute allowedRoles={['provider']} element={<ProviderProfileSetup />} />}
        />
        <Route
          path="provider/requests"
          element={<RoleRoute allowedRoles={['provider']} element={<JobRequests />} />}
        />
        <Route
          path="provider/payments"
          element={<RoleRoute allowedRoles={['provider']} element={<PaymentReviews />} />}
        />

        {/* 🛡️ Admin Routes (Protected) */}
        <Route
          path="admin/dashboard"
          element={<RoleRoute allowedRoles={['admin']} element={<AdminDashboard />} />}
        />
        <Route
          path="admin/verify"
          element={<RoleRoute allowedRoles={['admin']} element={<VerifyProviders />} />}
        />
        <Route
          path="admin/users"
          element={<RoleRoute allowedRoles={['admin']} element={<ManageUsers />} />}
        />
        <Route
          path="admin/bookings"
          element={<RoleRoute allowedRoles={['admin']} element={<ManageBookings />} />}
        />
        <Route
          path="admin/complaints"
          element={<RoleRoute allowedRoles={['admin']} element={<ComplaintsReports />} />}
        />
        <Route
          path="admin/analytics"
          element={<RoleRoute allowedRoles={['admin']} element={<AnalyticsReports />} />}
        />

        {/* 🚫 Unauthorized + 404 */}
        <Route path="unauthorized" element={<h2>⛔ Access Denied</h2>} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

export default App;
