// src/pages/admin/AdminDashboard.jsx

import React, { useEffect, useState } from 'react';
import { Box, Grid, Typography, Button, Stack } from '@mui/material';
import DashboardCard from '../../components/admin/DashboardCard';
import { useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    users: 0,
    providers: 0,
    bookings: 0,
    earnings: 0,
  });

  useEffect(() => {
    fetch('http://localhost:8000/api/admin/stats', {
      credentials: 'include',
    })
      .then((res) => res.json())
      .then((data) => setStats(data))
      .catch((err) => console.error('Error fetching stats:', err));
  }, []);

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Admin Dashboard
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={3}>
          <DashboardCard title="Total Users" value={stats.users} />
        </Grid>
        <Grid item xs={12} md={3}>
          <DashboardCard title="Total Providers" value={stats.providers} />
        </Grid>
        <Grid item xs={12} md={3}>
          <DashboardCard title="Total Bookings" value={stats.bookings} />
        </Grid>
        <Grid item xs={12} md={3}>
          <DashboardCard title="Total Earnings" value={`PKR ${stats.earnings}`} />
        </Grid>
      </Grid>

      <Box sx={{ mt: 5 }}>
        <Typography variant="h6" gutterBottom>
          Admin Actions
        </Typography>
        <Stack direction="row" spacing={2}>
          <Button variant="contained" onClick={() => navigate('/admin/users')}>
            Manage Users
          </Button>
          <Button variant="contained" onClick={() => navigate('/admin/verify')}>
            Verify Providers
          </Button>
          <Button variant="contained" onClick={() => navigate('/admin/bookings')}>
            Manage Bookings
          </Button>
          <Button variant="contained" onClick={() => navigate('/admin/analytics')}>
            View Reports
          </Button>
        </Stack>
      </Box>
    </Box>
  );
};

export default AdminDashboard;
