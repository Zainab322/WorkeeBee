import React from 'react';
import { Box, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Typography } from '@mui/material';

const ReportsTable = ({ reports }) => {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Report ID</TableCell>
            <TableCell>Reported By</TableCell>
            <TableCell>Reported User</TableCell>
            <TableCell>Type</TableCell>
            <TableCell>Description</TableCell>
            <TableCell>Date</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {reports.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} align="center">
                No reports found
              </TableCell>
            </TableRow>
          ) : (
            reports.map((report) => (
              <TableRow key={report.id}>
                <TableCell>{report.id}</TableCell>
                <TableCell>{report.reportedBy}</TableCell>
                <TableCell>{report.reportedUser}</TableCell>
                <TableCell>{report.type}</TableCell>
                <TableCell>
                  <Box sx={{ maxWidth: 200 }}>
                    <Typography noWrap>{report.description}</Typography>
                  </Box>
                </TableCell>
                <TableCell>{report.date}</TableCell>
                <TableCell>
                  <Box
                    sx={{
                      display: 'inline-block',
                      px: 1,
                      py: 0.5,
                      borderRadius: 1,
                      backgroundColor:
                        report.status === 'resolved'
                          ? 'success.light'
                          : report.status === 'in_progress'
                          ? 'warning.light'
                          : 'error.light',
                      color:
                        report.status === 'resolved'
                          ? 'success.dark'
                          : report.status === 'in_progress'
                          ? 'warning.dark'
                          : 'error.dark',
                    }}
                  >
                    {report.status.replace('_', ' ')}
                  </Box>
                </TableCell>
                <TableCell>
                  <Button size="small" variant="outlined" sx={{ mr: 1 }}>
                    View
                  </Button>
                  <Button
                    size="small"
                    variant="contained"
                    color={
                      report.status === 'resolved' ? 'secondary' : 'success'
                    }
                  >
                    {report.status === 'resolved' ? 'Reopen' : 'Resolve'}
                  </Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default ReportsTable;