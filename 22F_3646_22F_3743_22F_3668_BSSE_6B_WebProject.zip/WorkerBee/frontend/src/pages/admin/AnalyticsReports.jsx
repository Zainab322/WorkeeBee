import React, { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CircularProgress,
} from '@mui/material';

const AnalyticsReports = () => {
  const [reports, setReports] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:8000/api/admin/reports', {
      credentials: 'include',
    })
      .then((res) => res.json())
      .then((data) => {
        setReports(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('❌ Failed to fetch reports:', err);
        setLoading(false);
      });
  }, []);

  if (loading || !reports) {
    return (
      <Box sx={{ textAlign: 'center', mt: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
        Analytics & Reports
      </Typography>

      <Grid container spacing={3}>
        {/* Most Booked Services */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Most Booked Services
              </Typography>
              {reports.mostBookedServices.map((item, index) => (
                <Typography key={index}>
                  {item.serviceType}: {item.total} bookings
                </Typography>
              ))}
            </CardContent>
          </Card>
        </Grid>

        {/* Top Rated Providers */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Top Rated Providers
              </Typography>
              {reports.topProviders.map((provider, index) => (
                <Typography key={index}>
                  {provider.name} ({provider.service}) - ⭐ {provider.rating}
                </Typography>
              ))}
            </CardContent>
          </Card>
        </Grid>

        {/* Peak Booking Hours */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Peak Booking Hours
              </Typography>
              {reports.peakHours.map((hour, index) => (
                <Typography key={index}>
                  {hour.hour}: {hour.count} bookings
                </Typography>
              ))}
            </CardContent>
          </Card>
        </Grid>

        {/* Top Cities by Demand */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Top Cities by Demand
              </Typography>
              {reports.topCities.map((city, index) => (
                <Typography key={index}>
                  {city.city}: {city.count} bookings
                </Typography>
              ))}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default AnalyticsReports;
