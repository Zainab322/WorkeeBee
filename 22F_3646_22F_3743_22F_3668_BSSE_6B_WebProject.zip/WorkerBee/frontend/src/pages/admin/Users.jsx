import React, { useEffect, useState } from 'react';
import { Box, Typography } from '@mui/material';
import UserTable from '../../components/admin/UserTable';

const Users = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8000/api/admin/users', {
      credentials: 'include',
    })
      .then((res) => res.json())
      .then((data) => setUsers(data))
      .catch((err) => console.error('Error fetching users:', err));
  }, []);

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        User Management
      </Typography>
      <UserTable users={users} />
    </Box>
  );
};

export default Users;
