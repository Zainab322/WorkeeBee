import React from 'react';
import { Box, Button, Card, CardContent, Divider, Grid, Typography } from '@mui/material';

const ProviderVerificationCard = ({ provider, onApprove, onReject }) => {
  return (
    <Card>
      <CardContent>
        <Typography variant="h6" component="h3" gutterBottom>
          {provider.name} - {provider.serviceType}
        </Typography>
        
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} md={6}>
            <Typography variant="body1">
              <strong>City:</strong> {provider.city}
            </Typography>
            <Typography variant="body1">
              <strong>Experience:</strong> {provider.experience} years
            </Typography>
          </Grid>
          <Grid item xs={12} md={6}>
            <Typography variant="body1">
              <strong>CNIC:</strong> {provider.cnic}
            </Typography>
          </Grid>
        </Grid>

        <Divider sx={{ my: 2 }} />

        <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 600 }}>
          Submitted Documents:
        </Typography>
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
          {provider.documents.map((doc, index) => (
            <Button key={index} variant="outlined" size="small">
              {doc}
            </Button>
          ))}
        </Box>

        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
          <Button
            variant="outlined"
            color="error"
            onClick={onReject}
            sx={{ px: 4 }}
          >
            Reject
          </Button>
          <Button
            variant="contained"
            onClick={onApprove}
            sx={{ px: 4 }}
          >
            Approve
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
};

export default ProviderVerificationCard;