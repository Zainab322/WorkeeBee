import React, { useEffect, useState } from 'react';
import { Box, Typography } from '@mui/material';
import ProviderTable from '../../components/admin/ProviderTable';

const Providers = () => {
  const [providers, setProviders] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8000/api/admin/providers', {
      credentials: 'include',
    })
      .then((res) => res.json())
      .then((data) => setProviders(data))
      .catch((err) => console.error('Error fetching providers:', err));
  }, []);

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Provider Management
      </Typography>
      <ProviderTable providers={providers} />
    </Box>
  );
};

export default Providers;
