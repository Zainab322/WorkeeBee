import React, { useEffect, useState } from 'react';
import { Box, Typography } from '@mui/material';
import BookingTable from '../../components/admin/BookingTable'; // ✅ cleaner, consistent

const Bookings = () => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8000/api/admin/bookings', {
      credentials: 'include',
    })
      .then((res) => res.json())
      .then((data) => setBookings(data))
      .catch((err) => console.error('Error fetching bookings:', err));
  }, []);

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Booking Management
      </Typography>
      <BookingTable bookings={bookings} />
    </Box>
  );
};

export default Bookings;
