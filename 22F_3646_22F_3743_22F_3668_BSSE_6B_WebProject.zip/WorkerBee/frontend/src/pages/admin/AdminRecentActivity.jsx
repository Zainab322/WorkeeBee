import React from 'react';
import { Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Chip } from '@mui/material';
import { Button, Grid, Typography } from '@mui/material';

const AdminRecentActivity = ({ activities }) => {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Type</TableCell>
            <TableCell>Name</TableCell>
            <TableCell>Time</TableCell>
            <TableCell>Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {activities.map((activity) => (
            <TableRow key={activity.id}>
              <TableCell>
                <Chip label={activity.type} size="small" />
              </TableCell>
              <TableCell>{activity.name}</TableCell>
              <TableCell>{activity.time}</TableCell>
              <TableCell>
                <Chip 
                  label={activity.action} 
                  size="small" 
                  color={
                    activity.action === 'Needs verification' ? 'warning' : 
                    activity.action === 'Pending review' ? 'error' : 'success'
                  }
                />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default AdminRecentActivity;