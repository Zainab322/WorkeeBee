import React, { useState } from 'react';
import { Box, Button, Card, CardContent, Grid, TextField, Typography } from '@mui/material';
import ReportsTable from './ReportsTable';  // instead of '../../components/admin/ReportsTable'

const ComplaintsReports = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Mock data - replace with API call
  const reports = [
    {
      id: 'R001',
      reportedBy: 'Sarah Johnson',
      reportedUser: 'Aisha Khan',
      type: 'Service Quality',
      description: 'Provider arrived late and did not complete all tasks',
      date: '2023-06-12',
      status: 'pending',
    },
    {
      id: 'R002',
      reportedBy: 'Michael Chen',
      reportedUser: 'Ali Ahmed',
      type: 'Behavior',
      description: 'Provider was rude and unprofessional',
      date: '2023-05-28',
      status: 'in_progress',
    },
    {
      id: 'R003',
      reportedBy: 'Ali Raza',
      reportedUser: 'Fatima Raza',
      type: 'Payment Issue',
      description: 'Provider requested additional payment after service',
      date: '2023-05-15',
      status: 'resolved',
    },
  ];

  const filteredReports = reports.filter((report) => {
    const matchesSearch = report.reportedBy.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         report.reportedUser.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         report.type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || report.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 700 }}>
        Complaints & Reports
      </Typography>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Search Reports"
                variant="outlined"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                select
                fullWidth
                label="Filter by Status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                SelectProps={{
                  native: true,
                }}
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="in_progress">In Progress</option>
                <option value="resolved">Resolved</option>
              </TextField>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth variant="contained">
                New Report
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      <ReportsTable reports={filteredReports} />
    </Box>
  );
};

export default ComplaintsReports;