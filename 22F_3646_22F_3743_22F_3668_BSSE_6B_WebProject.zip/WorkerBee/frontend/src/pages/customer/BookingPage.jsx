import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Grid,
  Stepper,
  Step,
  StepLabel,
  Typography,
  TextField,
} from '@mui/material';
import { useParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

const steps = ['Select Date & Time', 'Service Details', 'Confirmation'];

const BookingPage = () => {
  const { id } = useParams();
  const { user, token, loading: authLoading } = useAuth();
  const [activeStep, setActiveStep] = useState(0);
  const [provider, setProvider] = useState(null);
  const [loading, setLoading] = useState(true);
  const [bookingDetails, setBookingDetails] = useState({
    date: '',
    time: '',
    address: '',
    instructions: '',
  });

  useEffect(() => {
    fetch(`http://localhost:8000/api/providers/${id}`)
      .then((res) => res.json())
      .then((data) => {
        console.log('✅ Provider fetched:', data);
        setProvider(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('❌ Error fetching provider:', err);
        setLoading(false);
      });
  }, [id]);

  const handleNext = () => setActiveStep((prev) => prev + 1);
  const handleBack = () => setActiveStep((prev) => prev - 1);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBookingDetails((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    if (!user || !user._id) {
      alert('⚠️ You must be logged in to make a booking.');
      console.error('❌ No logged in user.');
      return;
    }

    const payload = {
      customerId: user._id,
      providerId: provider._id,
      date: bookingDetails.date,
      timeSlot: bookingDetails.time,
      address: bookingDetails.address,
      notes: bookingDetails.instructions,
    };

    try {
      const res = await fetch('http://localhost:8000/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error('Failed to create booking');

      const result = await res.json();
      console.log('✅ Booking created:', result);
      handleNext();
    } catch (err) {
      console.error('❌ Error submitting booking:', err);
    }
  };

  if (loading || authLoading) return <Typography sx={{ p: 4 }}>Loading...</Typography>;
  if (!provider) return <Typography sx={{ p: 4 }}>Provider not found.</Typography>;

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Book {provider.name}
      </Typography>

      <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      <Card>
        <CardContent>
          {activeStep === 0 && (
            <Box>
              <Typography variant="h6" gutterBottom>Select Date and Time</Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    type="date"
                    name="date"
                    value={bookingDetails.date}
                    onChange={handleChange}
                    label="Booking Date"
                    InputLabelProps={{ shrink: true }}
                    required
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" gutterBottom>Available Time Slots</Typography>
                  <Grid container spacing={1}>
                    {['9:00 AM', '11:00 AM', '1:00 PM', '3:00 PM', '5:00 PM'].map((time) => (
                      <Grid item xs={6} sm={4} key={time}>
                        <Button
                          fullWidth
                          variant={bookingDetails.time === time ? 'contained' : 'outlined'}
                          onClick={() => setBookingDetails({ ...bookingDetails, time })}
                        >
                          {time}
                        </Button>
                      </Grid>
                    ))}
                  </Grid>
                </Grid>
              </Grid>
            </Box>
          )}

          {activeStep === 1 && (
            <Box>
              <Typography variant="h6" gutterBottom>Service Details</Typography>
              <TextField
                fullWidth
                label="Service Address"
                name="address"
                value={bookingDetails.address}
                onChange={handleChange}
                margin="normal"
                required
              />
              <TextField
                fullWidth
                label="Special Instructions"
                name="instructions"
                value={bookingDetails.instructions}
                onChange={handleChange}
                margin="normal"
                multiline
                rows={4}
              />
              <Box sx={{ mt: 3 }}>
                <Typography>Service: {provider.serviceType}</Typography>
                <Typography>Provider: {provider.name}</Typography>
                <Typography>Rate: PKR {provider.hourlyRate || 'N/A'}/hour</Typography>
              </Box>
            </Box>
          )}

          {activeStep === 2 && (
            <Box>
              <Typography variant="h6" gutterBottom>Confirm Your Booking</Typography>
              <Typography><strong>Date:</strong> {bookingDetails.date}</Typography>
              <Typography><strong>Time:</strong> {bookingDetails.time}</Typography>
              <Typography><strong>Address:</strong> {bookingDetails.address}</Typography>
              <Typography><strong>Instructions:</strong> {bookingDetails.instructions || 'None'}</Typography>
              <Typography sx={{ mt: 3 }}>
                <strong>Total:</strong> PKR {provider.hourlyRate ? provider.hourlyRate * 2 : 'N/A'} (2 hours)
              </Typography>
            </Box>
          )}

          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
            <Button disabled={activeStep === 0} onClick={handleBack}>Back</Button>
            {activeStep === steps.length - 1 ? (
              <Button variant="contained" onClick={handleSubmit}>Confirm Booking</Button>
            ) : (
              <Button
                variant="contained"
                onClick={handleNext}
                disabled={activeStep === 0 && !bookingDetails.time}
              >
                Next
              </Button>
            )}
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
};

export default BookingPage;
