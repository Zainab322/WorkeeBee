import React, { useEffect, useState } from 'react';
import { Box, Card, CardContent, Tab, Tabs, Typography, CircularProgress } from '@mui/material';
import BookingHistoryTable from '../customer/BookingHistoryTable'; // Adjust path if needed

const BookingHistory = () => {
  const [tabValue, setTabValue] = useState(0);
  const [upcoming, setUpcoming] = useState([]);
  const [past, setPast] = useState([]);
  const [loading, setLoading] = useState(true);

  const handleTabChange = (event, newValue) => setTabValue(newValue);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [upcomingRes, pastRes] = await Promise.all([
          fetch('http://localhost:8000/api/bookings/upcoming', { credentials: 'include' }),
          fetch('http://localhost:8000/api/bookings/past', { credentials: 'include' })
        ]);

        const upcomingData = await upcomingRes.json();
        const pastData = await pastRes.json();

        setUpcoming(upcomingData.bookings || []);
        setPast(pastData.bookings || []);
        setLoading(false);
      } catch (err) {
        console.error('❌ Failed to fetch booking history:', err);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 700 }}>
        Booking History
      </Typography>

      <Card>
        <CardContent>
          <Tabs value={tabValue} onChange={handleTabChange} sx={{ mb: 3 }}>
            <Tab label="Upcoming" />
            <Tab label="Past Bookings" />
          </Tabs>

          {loading ? (
            <Box sx={{ textAlign: 'center', mt: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <>
              {tabValue === 0 && <BookingHistoryTable bookings={upcoming} type="upcoming" />}
              {tabValue === 1 && <BookingHistoryTable bookings={past} type="past" />}
            </>
          )}
        </CardContent>
      </Card>
    </Box>
  );
};

export default BookingHistory;
