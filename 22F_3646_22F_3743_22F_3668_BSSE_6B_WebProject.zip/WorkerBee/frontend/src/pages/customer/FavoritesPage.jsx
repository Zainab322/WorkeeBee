import React, { useEffect, useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Grid,
  Typography,
  CircularProgress,
  IconButton
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import ProviderCard from '../../components/customer/ProviderCard';
import { useAuth } from '../../contexts/AuthContext';

const FavoritesPage = () => {
  const { user, token } = useAuth();
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || !user._id) return;

    fetch(`http://localhost:8000/api/favorites/${user._id}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      credentials: 'include'
    })
      .then((res) => {
        if (!res.ok) throw new Error('Failed to fetch favorites');
        return res.json();
      })
      .then((data) => {
        console.log("✅ Fetched favorites:", data);
        setFavorites(data || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error('❌ Error fetching favorites:', err);
        setLoading(false);
      });
  }, [user, token]);

  const handleRemoveFavorite = async (providerId) => {
    try {
      const res = await fetch(`http://localhost:8000/api/favorites/${user._id}/${providerId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`
        },
        credentials: 'include'
      });

      if (!res.ok) throw new Error('Failed to remove favorite');

      setFavorites((prev) => prev.filter((fav) => fav.providerId?._id !== providerId));
    } catch (err) {
      console.error('❌ Failed to remove favorite:', err);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 700 }}>
        My Favorites
      </Typography>

      {loading ? (
        <Box sx={{ textAlign: 'center', mt: 6 }}>
          <CircularProgress />
        </Box>
      ) : favorites.length === 0 ? (
        <Card>
          <CardContent sx={{ textAlign: 'center', py: 6 }}>
            <Typography variant="h6" gutterBottom>
              You haven't saved any providers yet
            </Typography>
            <Typography variant="body1" color="text.secondary">
              Browse providers and click the heart icon to add them to your favorites
            </Typography>
          </CardContent>
        </Card>
      ) : (
        <Grid container spacing={3}>
          {favorites.map((fav) =>
            fav.providerId ? (
              <Grid item xs={12} sm={6} md={4} key={fav._id}>
                <ProviderCard
                  provider={fav.providerId}
                  actionIcon={
                    <IconButton
                      color="error"
                      onClick={() => handleRemoveFavorite(fav.providerId._id)}
                      aria-label="remove from favorites"
                    >
                      <DeleteIcon />
                    </IconButton>
                  }
                />
              </Grid>
            ) : null
          )}
        </Grid>
      )}
    </Box>
  );
};

export default FavoritesPage;
