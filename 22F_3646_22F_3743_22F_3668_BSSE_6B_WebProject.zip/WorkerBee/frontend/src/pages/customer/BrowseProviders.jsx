import React, { useEffect, useState } from 'react';
import { Box, Grid, TextField, MenuItem, Typography } from '@mui/material';
import ProviderCard from '../../components/customer/ProviderCard';

const BrowseProviders = () => {
  const [providers, setProviders] = useState([]);
  const [filters, setFilters] = useState({ area: '', serviceType: '' });

  useEffect(() => {
    const query = new URLSearchParams();
    if (filters.area) query.append('area', filters.area);
    if (filters.serviceType) query.append('serviceType', filters.serviceType);

    const url = `http://localhost:8000/api/providers?${query.toString()}`;
    console.log('🌐 Fetching:', url);

    fetch(url)
      .then((res) => res.json())
      .then((data) => {
        const result = Array.isArray(data.providers) ? data.providers : data;
        console.log('✅ Providers from backend:', result);
        setProviders(result);
      })
      .catch((err) => {
        console.error('❌ Error fetching providers:', err);
        setProviders([]);
      });
  }, [filters]);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom fontWeight={700}>
        Browse Service Providers
      </Typography>

      <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
        <TextField
          fullWidth
          label="Area"
          name="area"
          value={filters.area}
          onChange={handleFilterChange}
        />
        <TextField
          fullWidth
          select
          label="Service Type"
          name="serviceType"
          value={filters.serviceType}
          onChange={handleFilterChange}
        >
          <MenuItem value="">All Services</MenuItem>
          <MenuItem value="Babysitter">Babysitter</MenuItem>
          <MenuItem value="Cook">Cook</MenuItem>
          <MenuItem value="Maid">Maid</MenuItem>
          <MenuItem value="Plumber">Plumber</MenuItem>
          <MenuItem value="Electrician">Electrician</MenuItem>
        </TextField>
      </Box>

      <Grid container spacing={3}>
        {providers && providers.length > 0 ? (
          providers.map((provider, idx) => (
            <Grid item xs={12} sm={6} md={4} key={provider._id || idx}>
              <ProviderCard provider={provider} />
            </Grid>
          ))
        ) : (
          <Grid item xs={12}>
            <Typography>No providers found matching your filters.</Typography>
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

export default BrowseProviders;
