import React from 'react';
import { Box, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Rating } from '@mui/material';

const BookingHistoryTable = ({ bookings, type }) => {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Booking ID</TableCell>
            <TableCell>Provider</TableCell>
            <TableCell>Service</TableCell>
            <TableCell>Date & Time</TableCell>
            <TableCell>Amount</TableCell>
            <TableCell>Status</TableCell>
            {type === 'past' && <TableCell>Rating</TableCell>}
            <TableCell>Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {bookings.length === 0 ? (
            <TableRow>
              <TableCell colSpan={type === 'past' ? 8 : 7} align="center">
                No {type === 'upcoming' ? 'upcoming' : 'past'} bookings found
              </TableCell>
            </TableRow>
          ) : (
            bookings.map((booking) => (
              <TableRow key={booking.id}>
                <TableCell>{booking.id}</TableCell>
                <TableCell>{booking.providerName}</TableCell>
                <TableCell>{booking.serviceType}</TableCell>
                <TableCell>
                  {booking.date} at {booking.time}
                </TableCell>
                <TableCell>PKR {booking.amount}</TableCell>
                <TableCell>
                  <Box
                    sx={{
                      display: 'inline-block',
                      px: 1,
                      py: 0.5,
                      borderRadius: 1,
                      backgroundColor:
                        booking.status === 'Completed'
                          ? 'success.light'
                          : booking.status === 'Cancelled'
                          ? 'error.light'
                          : 'info.light',
                      color:
                        booking.status === 'Completed'
                          ? 'success.dark'
                          : booking.status === 'Cancelled'
                          ? 'error.dark'
                          : 'info.dark',
                    }}
                  >
                    {booking.status}
                  </Box>
                </TableCell>
                {type === 'past' && (
                  <TableCell>
                    {booking.rating ? (
                      <Rating value={booking.rating} readOnly precision={0.5} />
                    ) : (
                      'Not rated'
                    )}
                  </TableCell>
                )}
                <TableCell>
                  {type === 'upcoming' ? (
                    <Button size="small" variant="outlined" color="error">
                      Cancel
                    </Button>
                  ) : (
                    <Button size="small" variant="outlined">
                      {booking.rating ? 'View Details' : 'Rate'}
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default BookingHistoryTable;