import React from 'react';
import { 
  Box, 
  Typography, 
  Container, 
  Grid, 
  Paper, 
  LinearProgress,
  List,
  ListItem,
  ListItemIcon,
  Divider,
  Button
} from '@mui/material';
import {
  Phone as PhoneIcon,
  Email as EmailIcon,
  LocationOn as LocationIcon,
  Star as StarIcon,
  CheckCircle as CheckCircleIcon
} from '@mui/icons-material';
import './AboutUs.css';

const AboutUs = () => {
  const skills = [
    { name: 'Service Matching', value: 90 },
    { name: 'Provider Verification', value: 95 },
    { name: 'Customer Satisfaction', value: 88 }
  ];

  const stats = [
    { number: '20+', label: 'Years Combined Experience' },
    { number: '1,000+', label: 'Services Booked' },
    { number: '300+', label: 'Verified Providers' },
    { number: '98%', label: 'Positive Ratings' }
  ];

  return (
    <Box className="about-us-container">
      {/* Hero Section */}
      <Box className="about-hero">
        <Container maxWidth="lg">
          <Typography variant="h2" className="hero-title">
            About WorkerBee
          </Typography>
          <Typography variant="subtitle1" className="hero-subtitle">
            Connecting you with trusted local service professionals
          </Typography>
        </Container>
      </Box>

      <Container maxWidth="lg" sx={{ py: 6 }}>
        {/* Mission Section */}
        <Grid container spacing={6} alignItems="center" sx={{ mb: 8 }}>
          <Grid item xs={12} md={6}>
            <Typography variant="h4" gutterBottom className="section-title">
              We Always Deliver The Best Service
            </Typography>
            <Typography variant="body1" paragraph className="section-text">
              WorkerBee is a smart platform connecting customers with trusted local service providers. 
              Whether you need a babysitter, electrician, plumber, or housemaid — our goal is to make 
              hiring easy, fast, and secure.
            </Typography>
            <Typography variant="body1" paragraph className="section-text">
              Our system ensures provider verification, real-time booking, ratings, and seamless communication. 
              With WorkerBee, quality help is just a click away.
            </Typography>
            <Box sx={{ mt: 3 }}>
              <Button 
                variant="contained" 
                color="primary" 
                size="large"
                className="cta-button"
              >
                Learn More
              </Button>
            </Box>
          </Grid>
          <Grid item xs={12} md={6}>
            <Paper elevation={3} className="about-image-paper">
              <img 
                src="/images/about-team.jpg" 
                alt="WorkerBee Team" 
                className="about-image"
              />
            </Paper>
          </Grid>
        </Grid>

        {/* Skills Section */}
        <Box sx={{ mb: 8 }}>
          <Typography variant="h4" align="center" gutterBottom className="section-title">
            Our Expertise
          </Typography>
          <Grid container spacing={4} sx={{ mt: 4 }}>
            {skills.map((skill, index) => (
              <Grid item xs={12} md={4} key={index}>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="h6" className="skill-name">
                    {skill.name}
                  </Typography>
                  <LinearProgress 
                    variant="determinate" 
                    value={skill.value} 
                    className="skill-progress"
                  />
                  <Typography variant="body2" className="skill-percentage">
                    {skill.value}%
                  </Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Box>

        {/* Stats Section */}
        <Paper elevation={0} className="stats-paper">
          <Grid container spacing={2}>
            {stats.map((stat, index) => (
              <Grid item xs={6} sm={3} key={index}>
                <Box className="stat-box">
                  <Typography variant="h3" className="stat-number">
                    {stat.number}
                  </Typography>
                  <Typography variant="subtitle1" className="stat-label">
                    {stat.label}
                  </Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Paper>

        {/* CTA Section */}
        <Box className="cta-section" sx={{ mt: 8 }}>
          <Typography variant="h3" align="center" className="cta-title">
            Ready to Experience WorkerBee?
          </Typography>
          <Typography variant="subtitle1" align="center" className="cta-subtitle">
            Join thousands of satisfied customers who trust us for their service needs
          </Typography>
          <Box sx={{ textAlign: 'center', mt: 4 }}>
            <Button 
              variant="contained" 
              color="secondary" 
              size="large"
              className="cta-button"
            >
              Get Started Now
            </Button>
          </Box>
        </Box>

        {/* Contact Section */}
        <Grid container spacing={6} sx={{ mt: 8 }}>
          <Grid item xs={12} md={6}>
            <Typography variant="h4" gutterBottom className="section-title">
              Our Story
            </Typography>
            <Typography variant="body1" paragraph className="section-text">
              Founded in 2020, WorkerBee began with a simple mission: to make finding reliable 
              home services as easy as ordering food delivery. What started as a small local 
              platform has grown into a nationwide service connecting thousands of customers 
              with qualified professionals every day.
            </Typography>
            <List>
              <ListItem className="feature-item">
                <ListItemIcon>
                  <CheckCircleIcon color="primary" />
                </ListItemIcon>
                <Typography>Rigorous provider vetting process</Typography>
              </ListItem>
              <ListItem className="feature-item">
                <ListItemIcon>
                  <CheckCircleIcon color="primary" />
                </ListItemIcon>
                <Typography>Real-time booking and scheduling</Typography>
              </ListItem>
              <ListItem className="feature-item">
                <ListItemIcon>
                  <CheckCircleIcon color="primary" />
                </ListItemIcon>
                <Typography>Secure payment system</Typography>
              </ListItem>
            </List>
          </Grid>
          <Grid item xs={12} md={6}>
            <Paper elevation={3} className="contact-paper">
              <Typography variant="h5" gutterBottom className="contact-title">
                Get In Touch
              </Typography>
              <Divider sx={{ mb: 3 }} />
              <List>
                <ListItem className="contact-item">
                  <ListItemIcon>
                    <LocationIcon color="primary" />
                  </ListItemIcon>
                  <Typography>123 Service Ave, Worker City, WC 10001</Typography>
                </ListItem>
                <ListItem className="contact-item">
                  <ListItemIcon>
                    <PhoneIcon color="primary" />
                  </ListItemIcon>
                  <Typography>(123) 456-7890</Typography>
                </ListItem>
                <ListItem className="contact-item">
                  <ListItemIcon>
                    <EmailIcon color="primary" />
                  </ListItemIcon>
                  <Typography>support@workerbee.com</Typography>
                </ListItem>
              </List>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default AboutUs;