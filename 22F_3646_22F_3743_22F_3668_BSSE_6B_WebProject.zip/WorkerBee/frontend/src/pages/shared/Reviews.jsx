import React from 'react';
import { Box, Divider, Typography, Rating } from '@mui/material';

const Reviews = ({ reviews }) => {
  return (
    <Box>
      <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
        Customer Reviews
      </Typography>
      {reviews.length === 0 ? (
        <Typography color="text.secondary">No reviews yet</Typography>
      ) : (
        reviews.map((review, index) => (
          <Box key={review.id} sx={{ mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
              <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                {review.customer}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {review.date}
              </Typography>
            </Box>
            <Rating value={review.rating} readOnly precision={0.5} size="small" />
            <Typography variant="body1" sx={{ mt: 1 }}>
              {review.comment}
            </Typography>
            {index < reviews.length - 1 && <Divider sx={{ my: 2 }} />}
          </Box>
        ))
      )}
    </Box>
  );
};

export default Reviews;