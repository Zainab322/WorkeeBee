import React, { useState } from 'react';
import { Box, Button, Card, CardContent, Divider, Grid, Tab, Tabs, Typography } from '@mui/material';
import Rating from '@mui/material/Rating';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import WorkHistoryIcon from '@mui/icons-material/WorkHistory';
import StarIcon from '@mui/icons-material/Star';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import Reviews from '../shared/Reviews';  // instead of '../../components/shared/Reviews'
import AvailabilityCalendar from '../shared/AvailabilityCalendar';  // instead of '../../components/shared/AvailabilityCalendar'
import { useParams } from 'react-router-dom';
import { Chip, TextField } from '@mui/material';

const ProviderProfile = () => {
  const { id } = useParams();
  const [tabValue, setTabValue] = useState(0);

  // Mock data - replace with API call to fetch provider details
  const provider = {
    id: id,
    name: 'Aisha Khan',
    serviceType: 'Cook',
    rating: 4.8,
    reviews: 42,
    experience: 5,
    city: 'Karachi',
    hourlyRate: 500,
    about: 'Professional cook with 5 years of experience in preparing delicious home meals. Specialized in Pakistani and continental cuisine.',
    skills: ['Meal Planning', 'Dietary Restrictions', 'Food Safety', 'Baking'],
    availability: ['Monday-Friday: 9AM-5PM', 'Saturday: 10AM-2PM'],
  };

  const reviews = [
    {
      id: 1,
      customer: 'Sarah Johnson',
      rating: 5,
      comment: 'Aisha is an amazing cook! Her biryani is to die for.',
      date: '2023-05-15',
    },
    {
      id: 2,
      customer: 'Michael Chen',
      rating: 4,
      comment: 'Very professional and clean. Food was delicious!',
      date: '2023-04-22',
    },
  ];

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <Box sx={{ p: 3 }}>
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <Box
                sx={{
                  width: 150,
                  height: 150,
                  borderRadius: '50%',
                  backgroundColor: 'grey.200',
                  mx: 'auto',
                  mb: 2,
                  overflow: 'hidden',
                }}
              >
                <img
                  src="/default-profile.jpg"
                  alt={provider.name}
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
              </Box>
              <Typography variant="h5" component="h2" gutterBottom>
                {provider.name}
              </Typography>
              <Chip label={provider.serviceType} color="primary" sx={{ mb: 2 }} />
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                <Rating value={provider.rating} precision={0.1} readOnly sx={{ mr: 1 }} />
                <Typography variant="body2" color="text.secondary">
                  {provider.rating} ({provider.reviews} reviews)
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                <LocationOnIcon color="action" sx={{ mr: 1, fontSize: '1rem' }} />
                <Typography variant="body2">{provider.city}</Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 2 }}>
                <WorkHistoryIcon color="action" sx={{ mr: 1, fontSize: '1rem' }} />
                <Typography variant="body2">{provider.experience} years experience</Typography>
              </Box>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                PKR {provider.hourlyRate}/hr
              </Typography>
              <Button
                fullWidth
                variant="contained"
                sx={{ mb: 2 }}
                onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}
              >
                Book Now
              </Button>
              <Button fullWidth variant="outlined">
                Message
              </Button>
            </CardContent>
          </Card>

          <Card sx={{ mt: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Skills
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {provider.skills.map((skill, index) => (
                  <Chip key={index} label={skill} variant="outlined" />
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Tabs value={tabValue} onChange={handleTabChange} sx={{ mb: 3 }}>
                <Tab label="About" />
                <Tab label="Reviews" />
                <Tab label="Availability" />
              </Tabs>

              {tabValue === 0 && (
                <Box>
                  <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                    About
                  </Typography>
                  <Typography paragraph>{provider.about}</Typography>
                  <Divider sx={{ my: 2 }} />
                  <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                    General Availability
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <CalendarMonthIcon color="action" sx={{ mr: 1 }} />
                    <Typography>{provider.availability[0]}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <CalendarMonthIcon color="action" sx={{ mr: 1 }} />
                    <Typography>{provider.availability[1]}</Typography>
                  </Box>
                </Box>
              )}

              {tabValue === 1 && <Reviews reviews={reviews} />}

              {tabValue === 2 && <AvailabilityCalendar />}
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Booking Section */}
      <Box id="booking-section" sx={{ mt: 4 }}>
        <Card>
          <CardContent>
            <Typography variant="h5" gutterBottom sx={{ fontWeight: 600 }}>
              Book {provider.name}
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="h6" gutterBottom>
                  Select Date
                </Typography>
                {/* Date picker component would go here */}
                <Box sx={{ height: 300, backgroundColor: 'grey.100', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Typography color="text.secondary">Calendar Component</Typography>
                </Box>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="h6" gutterBottom>
                  Service Details
                </Typography>
                <TextField
                  fullWidth
                  label="Service Address"
                  margin="normal"
                />
                <TextField
                  fullWidth
                  label="Special Instructions"
                  margin="normal"
                  multiline
                  rows={4}
                />
                <Box sx={{ mt: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Estimated Total: PKR {provider.hourlyRate * 2} (2 hours)
                  </Typography>
                  <Button fullWidth variant="contained" size="large">
                    Confirm Booking
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Box>
    </Box>
  );
};

export default ProviderProfile;