import React from 'react';
import { Box, Typography } from '@mui/material';

const AvailabilityCalendar = () => {
  // This would be replaced with a proper calendar component like FullCalendar
  return (
    <Box>
      <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
        Availability Calendar
      </Typography>
      <Box sx={{ height: 400, backgroundColor: 'grey.100', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Typography color="text.secondary">Calendar Component</Typography>
      </Box>
    </Box>
  );
};

export default AvailabilityCalendar;