import React, { useState, useEffect } from 'react';
import { Button, Container, Grid, Typography, useTheme, Box, Paper, Fade, useMediaQuery } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './HomePage.css';
import ServiceCard from '../../components/common/ServiceCard';
import Testimonials from '../../components/common/Testimonials';
import { motion } from 'framer-motion';

const services = [
  { id: 1, name: 'Babysitter', icon: '👶', color: '#FF9AA2' },
  { id: 2, name: 'Cook', icon: '👨‍🍳', color: '#FFB7B2' },
  { id: 3, name: 'Maid', icon: '🧹', color: '#FFDAC1' },
  { id: 4, name: 'Plumber', icon: '🔧', color: '#E2F0CB' },
  { id: 5, name: 'Electrician', icon: '💡', color: '#B5EAD7' },
  { id: 6, name: 'Driver', icon: '🚗', color: '#C7CEEA' },
];

const heroImages = [
  '/assets/images/2.jpg',
  '/assets/images/7.1.jpg',
  '/assets/images/3.1.jpg',
  '/assets/images/5.1.jpg'
];

const HomePage = () => {
  const theme = useTheme();
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  useEffect(() => {
    setIsVisible(true);
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ overflowX: 'hidden' }}>
      {/* Hero Section with Slider */}
     {/* Hero Section with Enhanced Slider */}
<div className="homepage-hero">
  {/* Slider with Parallax Effect */}
  <div className="hero-slider-container">
    {heroImages.map((image, index) => (
      <motion.div
        key={index}
        className={`homepage-hero-image ${index === currentSlide ? 'active' : ''}`}
        style={{ 
          backgroundImage: `url(${image})`,
          scale: index === currentSlide ? 1 : 1.05,
          filter: index === currentSlide ? 'brightness(0.7)' : 'brightness(0.5) blur(2px)'
        }}
        animate={{
          opacity: index === currentSlide ? 1 : 0,
          zIndex: index === currentSlide ? 1 : 0
        }}
        transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
      />
    ))}
  </div>
  
  {/* Gradient Overlay */}
  <div className="homepage-hero-overlay" style={{
    background: `linear-gradient(to bottom, 
      rgba(0,0,0,0.8) 0%, 
      rgba(0,0,0,0.5) 50%, 
      rgba(0,0,0,0.3) 100%)`
  }} />
  
  {/* Content with Animation */}
  <Fade in={isVisible} timeout={1000}>
    <div className="homepage-hero-content">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Typography 
          variant="h2" 
          component="h1" 
          gutterBottom 
          sx={{ 
            fontWeight: 800,
            fontSize: { xs: '2.5rem', sm: '3.5rem', md: '4rem' },
            lineHeight: 1.2,
            mb: 2,
            letterSpacing: '-0.5px',
            color: 'white',
            textShadow: '0 2px 10px rgba(0,0,0,0.5)',
            '& span': {
              background: `linear-gradient(90deg, ${theme.palette.primary.light}, ${theme.palette.secondary.main})`,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              textShadow: 'none'
            }
          }}
        >
          Find <span>Trusted</span> Service Providers <br />Near You
        </Typography>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Typography 
          variant="h5" 
          gutterBottom 
          sx={{ 
            mb: 4,
            fontSize: { xs: '1.1rem', sm: '1.25rem', md: '1.5rem' },
            maxWidth: '800px',
            mx: 'auto',
            fontWeight: 400,
            color: 'rgba(255,255,255,0.9)',
            textShadow: '0 1px 3px rgba(0,0,0,0.5)'
          }}
        >
          Book verified professionals for all your household needs with just a few clicks
        </Typography>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Button
          variant="contained"
          color="secondary"
          size="large"
          onClick={() => navigate('/role-selection')}
          sx={{ 
            px: 6, 
            py: 2, 
            fontSize: '1.1rem',
            fontWeight: 600,
            borderRadius: '50px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
            textTransform: 'none',
            letterSpacing: '0.5px',
            background: `linear-gradient(135deg, ${theme.palette.secondary.main}, ${theme.palette.primary.main})`,
            '&:hover': {
              boxShadow: '0 6px 25px rgba(0,0,0,0.4)',
              transform: 'translateY(-2px)'
            },
            transition: 'all 0.3s ease'
          }}
        >
          Get Started
        </Button>
      </motion.div>
    </div>
  </Fade>
  
  {/* Enhanced Slider Navigation */}
  <div className="hero-slider-nav">
    {heroImages.map((_, index) => (
      <motion.button
        key={index}
        className={`slider-nav-item ${index === currentSlide ? 'active' : ''}`}
        onClick={() => setCurrentSlide(index)}
        aria-label={`Go to slide ${index + 1}`}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <motion.span
          animate={{ 
            width: index === currentSlide ? '100%' : '0%',
            backgroundColor: index === currentSlide ? theme.palette.secondary.main : 'rgba(255,255,255,0.3)'
          }}
          transition={{ duration: 0.3 }}
        />
      </motion.button>
    ))}
  </div>
  
  {/* Scroll Indicator */}
  <motion.div
    className="scroll-indicator"
    animate={{ y: [0, 15, 0] }}
    transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
  >
    <svg width="30" height="50" viewBox="0 0 30 50">
      <path 
        d="M15 0 L15 25 M15 25 L20 35 M15 25 L10 35" 
        stroke="white" 
        strokeWidth="2" 
        fill="none"
        strokeLinecap="round"
      />
      <circle cx="15" cy="45" r="1.5" fill="white" />
    </svg>
    <Typography variant="caption" sx={{ 
      color: 'rgba(255,255,255,0.8)', 
      mt: 1,
      fontSize: '0.8rem'
    }}>
      Scroll to explore
    </Typography>
  </motion.div>
</div>

      {/* Services Section */}
      <Container maxWidth="xl" sx={{ py: 10 }}>
        <Box textAlign="center" mb={6}>
          <Typography 
            variant="h3" 
            component="h2" 
            gutterBottom 
            sx={{ 
              fontWeight: 700,
              position: 'relative',
              display: 'inline-block',
              '&:after': {
                content: '""',
                position: 'absolute',
                bottom: -8,
                left: '50%',
                transform: 'translateX(-50%)',
                width: '80px',
                height: '4px',
                backgroundColor: theme.palette.primary.main,
                borderRadius: '2px'
              }
            }}
          >
            Our Services
          </Typography>
          <Typography 
            variant="subtitle1" 
            color="text.secondary" 
            sx={{ 
              mt: 3,
              fontSize: '1.1rem',
              maxWidth: '700px',
              mx: 'auto',
              lineHeight: 1.6
            }}
          >
            Choose from a wide range of professional services tailored to meet your household needs
          </Typography>
        </Box>
        <Grid container spacing={4} justifyContent="center">
          {services.map((service) => (
            <Grid item key={service.id} xs={12} sm={6} md={4} lg={2}>
              <motion.div
                whileHover={{ y: -10 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <ServiceCard service={service} />
              </motion.div>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Stats Section */}
      <Box sx={{ 
        backgroundColor: theme.palette.primary.main, 
        color: 'white',
        py: 8,
        position: 'relative',
        '&:before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: '10px',
          background: `linear-gradient(90deg, ${theme.palette.secondary.main}, ${theme.palette.primary.light})`
        }
      }}>
        <Container maxWidth="lg">
          <Grid container spacing={4} justifyContent="center" textAlign="center">
            {[
              { value: '10,000+', label: 'Happy Customers' },
              { value: '500+', label: 'Verified Professionals' },
              { value: '24/7', label: 'Customer Support' },
              { value: '98%', label: 'Satisfaction Rate' }
            ].map((stat, index) => (
              <Grid item xs={6} sm={3} key={index}>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Box>
                    <Typography variant="h2" sx={{ 
                      fontWeight: 700,
                      mb: 1,
                      fontSize: { xs: '2.5rem', sm: '3rem' }
                    }}>
                      {stat.value}
                    </Typography>
                    <Typography variant="h6" sx={{ 
                      fontWeight: 500,
                      opacity: 0.9,
                      fontSize: { xs: '0.9rem', sm: '1rem' }
                    }}>
                      {stat.label}
                    </Typography>
                  </Box>
                </motion.div>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

    {/* How It Works Section */}
<Box sx={{ 
  py: 10,
  position: 'relative',
  overflow: 'hidden',
  '&:before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundImage: 'url(/assets/images/4.jpg)',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundAttachment: 'fixed',
    opacity: 0.1,
    zIndex: 0
  }
}}>
  <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
    <Typography 
      variant="h3" 
      component="h2" 
      align="center" 
      gutterBottom 
      sx={{ 
        fontWeight: 700,
        mb: 6,
        position: 'relative',
        '&:after': {
          content: '""',
          position: 'absolute',
          bottom: -8,
          left: '50%',
          transform: 'translateX(-50%)',
          width: '80px',
          height: '4px',
          backgroundColor: theme.palette.primary.main,
          borderRadius: '2px'
        }
      }}
    >
      How WorkerBee Works
    </Typography>
    <Grid container spacing={4} justifyContent="center">
      {[
        { 
          step: 1, 
          title: 'Choose Your Service', 
          description: 'Browse our extensive list of verified service providers and select the one that fits your needs.',
          icon: '🔍'
        },
        { 
          step: 2, 
          title: 'Book & Confirm', 
          description: 'Pick a convenient time slot and confirm your booking with secure payment options.',
          icon: '📅'
        },
        { 
          step: 3, 
          title: 'Enjoy Quality Service', 
          description: 'Sit back and relax while our professionals deliver top-quality service to your doorstep.',
          icon: '✨'
        }
      ].map((item, index) => (
        <Grid item key={item.step} xs={12} md={4} sx={{ display: 'flex', justifyContent: 'center' }}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            style={{ width: '100%', maxWidth: '350px' }}
          >
            <Paper elevation={3} sx={{ 
              p: 4, 
              height: '100%',
              borderRadius: '16px',
              transition: 'transform 0.3s, box-shadow 0.3s',
              '&:hover': {
                transform: 'translateY(-5px)',
                boxShadow: theme.shadows[6]
              },
              borderTop: `4px solid ${theme.palette.primary.main}`,
              backgroundColor: 'rgba(255, 255, 255, 0.95)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              textAlign: 'center'
            }}>
              <Box sx={{
                width: 80,
                height: 80,
                borderRadius: '50%',
                backgroundColor: theme.palette.primary.light,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mx: 'auto',
                mb: 3,
                color: 'white',
                fontSize: '2rem',
                fontWeight: 700,
                boxShadow: `0 4px 20px ${theme.palette.primary.light}40`
              }}>
                {item.icon}
              </Box>
              <Typography variant="h5" gutterBottom sx={{ 
                fontWeight: 600, 
                mb: 2,
                color: theme.palette.primary.dark
              }}>
                {item.title}
              </Typography>
              <Typography color="text.secondary" sx={{ lineHeight: 1.7 }}>
                {item.description}
              </Typography>
            </Paper>
          </motion.div>
        </Grid>
      ))}
    </Grid>
  </Container>
</Box>

      {/* Dashboard Access Buttons (for development) */}
      {process.env.NODE_ENV === 'development' && (
        <Box sx={{ py: 4, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary" sx={{ mb: 2 }}>
            Quick Access (Development Only)
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2, flexWrap: 'wrap' }}>
            {[
              { label: 'Client Dashboard', path: '/customer/dashboard' },
              { label: 'Provider Dashboard', path: '/provider/dashboard' },
              { label: 'Admin Dashboard', path: '/admin/dashboard' }
            ].map((button, index) => (
              <motion.div
                key={button.label}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant="outlined"
                  onClick={() => navigate(button.path)}
                  sx={{
                    borderRadius: '50px',
                    px: 3,
                    textTransform: 'none',
                    borderWidth: '2px',
                    '&:hover': {
                      borderWidth: '2px'
                    },
                    fontWeight: 500
                  }}
                >
                  {button.label}
                </Button>
              </motion.div>
            ))}
          </Box>
        </Box>
      )}

      {/* Testimonials Section */}
      <Box sx={{ py: 10, backgroundColor: theme.palette.background.paper }}>
        <Container maxWidth="lg">
          <Typography 
            variant="h3" 
            component="h2" 
            align="center" 
            gutterBottom 
            sx={{ 
              fontWeight: 700,
              mb: 6,
              position: 'relative',
              '&:after': {
                content: '""',
                position: 'absolute',
                bottom: -8,
                left: '50%',
                transform: 'translateX(-50%)',
                width: '80px',
                height: '4px',
                backgroundColor: theme.palette.primary.main,
                borderRadius: '2px'
              }
            }}
          >
            What Our Customers Say
          </Typography>
          <Testimonials />
        </Container>
      </Box>

      {/* CTA Section */}
      <Box sx={{ 
        background: `linear-gradient(135deg, ${theme.palette.primary.dark} 0%, ${theme.palette.primary.main} 100%)`,
        py: 8,
        color: 'white',
        position: 'relative',
        overflow: 'hidden',
        '&:before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: '10px',
          background: `linear-gradient(90deg, ${theme.palette.secondary.main}, ${theme.palette.primary.light})`
        }
      }}>
        <Container maxWidth="lg">
          <Grid container alignItems="center" spacing={4}>
            <Grid item xs={12} md={8}>
              <Typography 
                variant="h3" 
                component="h3" 
                gutterBottom 
                sx={{ 
                  fontWeight: 700,
                  lineHeight: 1.2,
                  fontSize: isMobile ? '2rem' : '2.5rem'
                }}
              >
                Ready to find your perfect service provider?
              </Typography>
              <Typography variant="subtitle1" sx={{ 
                opacity: 0.9, 
                fontSize: '1.1rem',
                lineHeight: 1.7,
                mb: isMobile ? 3 : 0
              }}>
                Join thousands of satisfied customers who trust WorkerBee for their household needs.
                Get started today and experience the convenience of professional services at your fingertips.
              </Typography>
            </Grid>
            <Grid item xs={12} md={4} sx={{ 
              display: 'flex',
              justifyContent: { xs: 'flex-start', md: 'flex-end' }
            }}>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant="contained"
                  color="secondary"
                  size="large"
                  onClick={() => navigate('/role-selection')}
                  sx={{ 
                    px: 6, 
                    py: 2, 
                    fontSize: '1.1rem',
                    fontWeight: 600,
                    borderRadius: '50px',
                    boxShadow: '0 4px 20px rgba(0,0,0,0.2)',
                    '&:hover': {
                      boxShadow: '0 6px 25px rgba(0,0,0,0.3)'
                    },
                    textTransform: 'none',
                    whiteSpace: 'nowrap'
                  }}
                >
                  Get Started Now
                </Button>
              </motion.div>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </div>
  );
};

export default HomePage;