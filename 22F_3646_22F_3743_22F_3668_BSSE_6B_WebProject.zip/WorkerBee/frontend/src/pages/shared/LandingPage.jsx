import React from 'react';
import { useNavigate } from 'react-router-dom';

const LandingPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col justify-between bg-gray-50">
      {/* Navbar */}
      <header className="bg-white shadow">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-indigo-600">WorkerBee</h1>
          <nav className="space-x-6 text-gray-600">
            <button className="hover:text-indigo-600">About Us</button>
            <button className="hover:text-indigo-600">Contact</button>
            <button className="hover:text-indigo-600">FAQs</button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex flex-col items-center justify-center text-center py-20 px-6">
        <h2 className="text-4xl md:text-5xl font-extrabold text-gray-800 mb-4">Hire Smart. Work Easy.</h2>
        <p className="text-lg md:text-xl text-gray-600 max-w-xl mb-8">
          Find verified babysitters, electricians, cooks, and more — all in one platform.
        </p>
        <button
          onClick={() => navigate('/role-selection')}
          className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-semibold shadow hover:bg-indigo-700 transition"
        >
          Get Started
        </button>
      </main>

      {/* Footer */}
      <footer className="bg-gray-100 text-center py-6">
        <div className="flex justify-center gap-6 mb-2">
          <a href="#" className="text-gray-500 hover:text-indigo-600">Facebook</a>
          <a href="#" className="text-gray-500 hover:text-indigo-600">Twitter</a>
          <a href="#" className="text-gray-500 hover:text-indigo-600">LinkedIn</a>
        </div>
        <p className="text-sm text-gray-500">&copy; {new Date().getFullYear()} WorkerBee. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default LandingPage;
