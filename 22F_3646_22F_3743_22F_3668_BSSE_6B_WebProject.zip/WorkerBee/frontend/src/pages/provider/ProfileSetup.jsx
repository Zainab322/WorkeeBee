import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  TextField,
  Typography,
  MenuItem,
  Grid,
  CircularProgress,
} from '@mui/material';

const serviceTypes = ['Babysitter', 'Cook', 'Maid', 'Plumber', 'Electrician', 'Driver'];

const ProfileSetup = () => {
  const [formData, setFormData] = useState({
    name: '',
    cnic: '',
    phone: '',
    city: '',
    serviceType: '',
    experience: '',
  });

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    // Fetch existing profile
    fetch('http://localhost:8000/api/provider/profile', {
      credentials: 'include',
    })
      .then((res) => res.json())
      .then((data) => {
        if (data && data.profile) {
          setFormData({
            name: data.profile.name || '',
            cnic: data.profile.cnic || '',
            phone: data.profile.phone || '',
            city: data.profile.city || '',
            serviceType: data.profile.serviceType || '',
            experience: data.profile.experience || '',
          });
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error('❌ Error loading profile:', err);
        setLoading(false);
      });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const res = await fetch('http://localhost:8000/api/provider/profile', {
        method: 'PUT',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await res.json();
      if (res.ok) {
        alert('✅ Profile updated successfully');
      } else {
        alert('❌ Failed to update: ' + (result.message || 'Unknown error'));
      }
    } catch (err) {
      console.error('❌ Profile update failed:', err);
    }
    setSubmitting(false);
  };

  if (loading) {
    return (
      <Box sx={{ textAlign: 'center', mt: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
        Profile Setup
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Full Name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            fullWidth
            required
          />
        </Grid>

        <Grid item xs={12} sm={6}>
          <TextField
            label="CNIC"
            name="cnic"
            value={formData.cnic}
            onChange={handleChange}
            fullWidth
            required
          />
        </Grid>

        <Grid item xs={12} sm={6}>
          <TextField
            label="Phone Number"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            fullWidth
            required
          />
        </Grid>

        <Grid item xs={12} sm={6}>
          <TextField
            label="City / Area"
            name="city"
            value={formData.city}
            onChange={handleChange}
            fullWidth
            required
          />
        </Grid>

        <Grid item xs={12} sm={6}>
          <TextField
            label="Service Type"
            name="serviceType"
            value={formData.serviceType}
            onChange={handleChange}
            select
            fullWidth
            required
          >
            {serviceTypes.map((type) => (
              <MenuItem key={type} value={type}>
                {type}
              </MenuItem>
            ))}
          </TextField>
        </Grid>

        <Grid item xs={12} sm={6}>
          <TextField
            label="Years of Experience"
            name="experience"
            value={formData.experience}
            onChange={handleChange}
            fullWidth
            required
            type="number"
          />
        </Grid>
      </Grid>

      <Button
        sx={{ mt: 4 }}
        variant="contained"
        color="primary"
        onClick={handleSubmit}
        disabled={submitting}
      >
        {submitting ? 'Saving...' : 'Save Profile'}
      </Button>
    </Box>
  );
};

export default ProfileSetup;
