import React, { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Rating,
  CircularProgress,
  Divider,
} from '@mui/material';

const PaymentReviews = () => {
  const [data, setData] = useState([]);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:8000/api/provider/payments', {
      credentials: 'include',
    })
      .then((res) => res.json())
      .then((resData) => {
        setData(resData.payments || []);
        setTotalEarnings(resData.totalEarnings || 0);
        setLoading(false);
      })
      .catch((err) => {
        console.error('❌ Failed to load payments:', err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <Box sx={{ textAlign: 'center', mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
        Payment & Reviews
      </Typography>

      <Card sx={{ mb: 4 }}>
        <CardContent>
          <Typography variant="subtitle1">Total Earnings</Typography>
          <Typography variant="h5" color="primary">PKR {totalEarnings}</Typography>
        </CardContent>
      </Card>

      {data.length === 0 ? (
        <Typography>No completed jobs or reviews yet.</Typography>
      ) : (
        <Grid container spacing={3}>
          {data.map((item) => (
            <Grid item xs={12} md={6} key={item.id}>
              <Card>
                <CardContent>
                  <Typography variant="subtitle1">
                    {item.customerName} ({item.serviceType})
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {item.date} — PKR {item.amount}
                  </Typography>
                  <Divider sx={{ my: 1.5 }} />
                  <Typography variant="body2">
                    <strong>Rating:</strong>
                    {item.rating ? (
                      <Rating value={item.rating} precision={0.5} readOnly />
                    ) : (
                      ' Not rated'
                    )}
                  </Typography>
                  {item.review && (
                    <Typography sx={{ mt: 1 }}>
                      <strong>Review:</strong> {item.review}
                    </Typography>
                  )}
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  );
};

export default PaymentReviews;
