import React, { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  CircularProgress,
  List,
  ListItem,
  ListItemText,
  Divider,
  Button
} from '@mui/material';
import { useNavigate } from 'react-router-dom';

const ProviderDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [upcomingJobs, setUpcomingJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [statsRes, bookingsRes] = await Promise.all([
          fetch('http://localhost:8000/api/provider/stats', { credentials: 'include' }),
          fetch('http://localhost:8000/api/provider/bookings/upcoming', { credentials: 'include' })
        ]);

        const statsData = await statsRes.json();
        const bookingsData = await bookingsRes.json();

        setStats(statsData || {});
        setUpcomingJobs(bookingsData.bookings || []);
        setLoading(false);
      } catch (err) {
        console.error('❌ Failed to load dashboard:', err);
        setStats({});
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading || stats === null) {
    return (
      <Box sx={{ textAlign: 'center', mt: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
        Provider Dashboard
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="subtitle1">Total Earnings</Typography>
              <Typography variant="h5" color="primary">
                PKR {stats.totalEarnings ?? 0}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="subtitle1">Jobs Completed</Typography>
              <Typography variant="h5">{stats.totalJobs ?? 0}</Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="subtitle1">Average Rating</Typography>
              <Typography variant="h5">{stats.averageRating ?? 'N/A'}</Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Box sx={{ mt: 5 }}>
        <Typography variant="h6" gutterBottom>
          Upcoming Bookings
        </Typography>

        {upcomingJobs.length === 0 ? (
          <Typography color="text.secondary">No upcoming jobs</Typography>
        ) : (
          <List>
            {upcomingJobs.map((job) => (
              <React.Fragment key={job.id}>
                <ListItem>
                  <ListItemText
                    primary={`${job.customerName} (${job.serviceType})`}
                    secondary={`${job.date} at ${job.time} — ${job.address}`}
                  />
                </ListItem>
                <Divider />
              </React.Fragment>
            ))}
          </List>
        )}
      </Box>

      <Box sx={{ mt: 5 }}>
        <Typography variant="h6" gutterBottom>
          Quick Actions
        </Typography>
        <Grid container spacing={2}>
          <Grid item>
            <Button
              variant="contained"
              color="primary"
              onClick={() => navigate('/provider/profile-setup')}
            >
              Edit Profile
            </Button>
          </Grid>
          <Grid item>
            <Button
              variant="outlined"
              onClick={() => navigate('/provider/requests')}
            >
              View Job Requests
            </Button>
          </Grid>
          <Grid item>
            <Button
              variant="outlined"
              onClick={() => navigate('/provider/payments')}
            >
              Payment & Reviews
            </Button>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
};

export default ProviderDashboard;
