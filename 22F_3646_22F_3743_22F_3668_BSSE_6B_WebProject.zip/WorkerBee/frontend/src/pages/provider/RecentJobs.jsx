import React from 'react';
import { Card, CardContent, Typography, List, ListItem, ListItemText, Button } from '@mui/material';

const RecentJobs = ({ jobs }) => {
  return (
    <Card>
      <CardContent>
        <Typography variant="h6" gutterBottom>Recent Jobs</Typography>
        <List>
          {jobs?.length > 0 ? (
            jobs.map((job, index) => (
              <ListItem key={index}>
                <ListItemText
                  primary={job.title}
                  secondary={`${job.date} - ${job.status}`}
                />
                <Button size="small" variant="outlined">
                  View
                </Button>
              </ListItem>
            ))
          ) : (
            <Typography variant="body2" color="text.secondary">
              No recent jobs found
            </Typography>
          )}
        </List>
      </CardContent>
    </Card>
  );
};

export default RecentJobs;