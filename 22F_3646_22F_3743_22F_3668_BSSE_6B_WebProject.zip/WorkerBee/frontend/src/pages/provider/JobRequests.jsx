import React, { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  CircularProgress,
} from '@mui/material';
import JobRequestCard from '../../pages/provider/JobRequestCard';

const JobRequests = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:8000/api/provider/requests', {
      credentials: 'include',
    })
      .then((res) => res.json())
      .then((data) => {
        setRequests(data.requests || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error('❌ Failed to load job requests:', err);
        setLoading(false);
      });
  }, []);

  const handleDecision = async (id, action) => {
    try {
      const res = await fetch(
        `http://localhost:8000/api/provider/requests/${id}/${action}`,
        {
          method: 'POST',
          credentials: 'include',
        }
      );
      if (res.ok) {
        setRequests((prev) => prev.filter((req) => req.id !== id));
      } else {
        alert(`❌ Failed to ${action} request`);
      }
    } catch (err) {
      console.error(`❌ Error during ${action}:`, err);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
        Job Requests
      </Typography>

      {loading ? (
        <Box sx={{ textAlign: 'center', mt: 5 }}>
          <CircularProgress />
        </Box>
      ) : requests.length === 0 ? (
        <Typography>No job requests at the moment.</Typography>
      ) : (
        <Grid container spacing={3}>
          {requests.map((req) => (
            <Grid item xs={12} md={6} key={req.id}>
              <JobRequestCard
                request={req}
                onAccept={(id) => handleDecision(id, 'accept')}
                onReject={(id) => handleDecision(id, 'reject')}
              />
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  );
};

export default JobRequests;
