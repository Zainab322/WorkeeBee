import React from 'react';
import {
  Card,
  CardContent,
  Typography,
  Grid,
  Divider,
  Button,
} from '@mui/material';

const JobRequestCard = ({ request, onAccept, onReject }) => {
  return (
    <Card>
      <CardContent>
        <Typography variant="h6">{request.customerName}</Typography>
        <Typography variant="body2" color="text.secondary">
          {request.serviceType} — {request.date} at {request.time}
        </Typography>
        <Typography variant="body2" sx={{ mt: 1 }}>
          <strong>Address:</strong> {request.address}
        </Typography>
        <Typography variant="body2">
          <strong>Instructions:</strong> {request.instructions || 'N/A'}
        </Typography>

        <Divider sx={{ my: 2 }} />

        <Grid container spacing={2}>
          <Grid item>
            <Button
              variant="contained"
              color="success"
              onClick={() => onAccept(request.id)}
            >
              Accept
            </Button>
          </Grid>
          <Grid item>
            <Button
              variant="outlined"
              color="error"
              onClick={() => onReject(request.id)}
            >
              Reject
            </Button>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
};

export default JobRequestCard;
