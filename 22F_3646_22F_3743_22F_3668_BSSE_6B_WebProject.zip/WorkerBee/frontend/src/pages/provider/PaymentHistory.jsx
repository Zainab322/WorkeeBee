import React from 'react';
import { Box, Button, Card, CardContent, Divider, Typography } from '@mui/material';

const JobRequestCard = ({ job, onAccept, onReject }) => {
  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Typography variant="h6" component="h3">
            {job.customerName} - {job.serviceType}
          </Typography>
          <Box
            sx={{
              px: 1.5,
              py: 0.5,
              borderRadius: 1,
              backgroundColor: 'info.light',
              color: 'info.dark',
            }}
          >
            {job.status}
          </Box>
        </Box>

        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} md={6}>
            <Typography variant="body1">
              <strong>Date:</strong> {job.date}
            </Typography>
            <Typography variant="body1">
              <strong>Time:</strong> {job.time} ({job.duration})
            </Typography>
          </Grid>
          <Grid item xs={12} md={6}>
            <Typography variant="body1">
              <strong>Address:</strong> {job.address}
            </Typography>
          </Grid>
        </Grid>

        {job.specialInstructions && (
          <>
            <Divider sx={{ my: 2 }} />
            <Typography variant="body1">
              <strong>Special Instructions:</strong> {job.specialInstructions}
            </Typography>
          </>
        )}

        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2, mt: 3 }}>
          <Button
            variant="outlined"
            color="error"
            onClick={onReject}
            sx={{ px: 4 }}
          >
            Reject
          </Button>
          <Button
            variant="contained"
            onClick={onAccept}
            sx={{ px: 4 }}
          >
            Accept
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
};

export default JobRequestCard;