import React from 'react';
import { Box, Button, Container, Grid, Typography, useTheme } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import CustomerIcon from '@mui/icons-material/Person';
import ProviderIcon from '@mui/icons-material/Handyman';
import { Link } from 'react-router-dom';

const RoleSelection = () => {
  const theme = useTheme();
  const navigate = useNavigate();

  const handleRoleSelect = (role) => {
    navigate(`/register?role=${role}`);
  };

  return (
    <Container maxWidth="md" sx={{ py: 8 }}>
      <Typography variant="h3" component="h1" align="center" gutterBottom sx={{ fontWeight: 700 }}>
        Join WorkerBee
      </Typography>
      <Typography variant="subtitle1" align="center" color="text.secondary" sx={{ mb: 6 }}>
        Select your role to get started
      </Typography>

      <Grid container spacing={4} justifyContent="center">
        <Grid item xs={12} md={6}>
          <Box
            sx={{
              border: `1px solid ${theme.palette.divider}`,
              borderRadius: 2,
              p: 4,
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              textAlign: 'center',
              transition: 'all 0.3s',
              '&:hover': {
                boxShadow: 6,
                borderColor: theme.palette.primary.main,
              },
            }}
          >
            <CustomerIcon sx={{ fontSize: 80, color: theme.palette.primary.main, mb: 3 }} />
            <Typography variant="h5" component="h2" gutterBottom>
              I Need a Service
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
              Find and book verified service providers for your household needs.
            </Typography>
            <Button
              variant="contained"
              size="large"
              onClick={() => handleRoleSelect('customer')}
              sx={{ mt: 'auto' }}
            >
              Continue as Customer
            </Button>
          </Box>
        </Grid>

        <Grid item xs={12} md={6}>
          <Box
            sx={{
              border: `1px solid ${theme.palette.divider}`,
              borderRadius: 2,
              p: 4,
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              textAlign: 'center',
              transition: 'all 0.3s',
              '&:hover': {
                boxShadow: 6,
                borderColor: theme.palette.secondary.main,
              },
            }}
          >
            <ProviderIcon sx={{ fontSize: 80, color: theme.palette.secondary.main, mb: 3 }} />
            <Typography variant="h5" component="h2" gutterBottom>
              I Provide a Service
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
              Offer your skills and services to customers in your area.
            </Typography>
            <Button
              variant="contained"
              color="secondary"
              size="large"
              onClick={() => handleRoleSelect('provider')}
              sx={{ mt: 'auto' }}
            >
              Continue as Provider
            </Button>
          </Box>
        </Grid>
      </Grid>

      <Box sx={{ textAlign: 'center', mt: 6 }}>
        <Typography variant="body1" sx={{ mb: 2 }}>
          Already have an account?
        </Typography>
        <Button variant="outlined" onClick={() => navigate('/login')}>
          Sign In
        </Button>
      </Box>
    </Container>
  );
};

export default RoleSelection;