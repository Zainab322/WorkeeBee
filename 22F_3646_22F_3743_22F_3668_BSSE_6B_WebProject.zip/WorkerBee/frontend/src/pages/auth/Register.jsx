import React from 'react';
import { Box, Button, Container, Grid, MenuItem, TextField, Typography } from '@mui/material';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Link } from 'react-router-dom';

const validationSchema = yup.object({
  name: yup.string().required('Name is required'),
  email: yup.string().email('Enter a valid email').required('Email is required'),
  phone: yup.string().required('Phone number is required'),
  password: yup.string().min(8, 'Password should be at least 8 characters').required('Password is required'),
  confirmPassword: yup.string()
    .oneOf([yup.ref('password'), null], 'Passwords must match')
    .required('Confirm Password is required'),
  role: yup.string().required('Role is required'),
  serviceType: yup.string().when('role', {
    is: 'provider',
    then: () => yup.string().required('Service type is required'),
    otherwise: () => yup.string().notRequired(),
  }),
  city: yup.string().when('role', {
    is: 'provider',
    then: () => yup.string().required('City is required'),
    otherwise: () => yup.string().notRequired(),
  }),
  experience: yup.number()
    .transform((value, originalValue) =>
      String(originalValue).trim() === '' ? null : value
    )
    .nullable()
    .when('role', {
      is: 'provider',
      then: () =>
        yup.number().required('Experience is required').min(0, 'Experience cannot be negative'),
      otherwise: () => yup.number().notRequired(),
    }),
});

const serviceTypes = [
  'Babysitter', 'Cook', 'Maid', 'Plumber',
  'Electrician', 'Driver', 'Gardener', 'Painter',
];

const cities = [
  'Karachi', 'Lahore', 'Islamabad', 'Rawalpindi',
  'Faisalabad', 'Multan', 'Peshawar', 'Quetta',
];

const Register = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const role = searchParams.get('role') || 'customer';

  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      phone: '',
      password: '',
      confirmPassword: '',
      role: role,
      serviceType: '',
      city: '',
      experience: 0,
      cnic: '',
      certificates: null,
    },
    validationSchema: validationSchema,
    onSubmit: async (values, { setSubmitting, setErrors }) => {
      try {
        const formData = new FormData();
        Object.keys(values).forEach(key => {
          if (key === 'certificates' && values[key]) {
            Array.from(values[key]).forEach(file => {
              formData.append('certificates', file);
            });
          } else if (values[key] !== null && values[key] !== undefined) {
            formData.append(key, values[key]);
          }
        });

        const result = await register(formData);
        if (result.success) {
          navigate(`/${values.role}/dashboard`);
        } else {
          setErrors({ submit: result.message });
        }
      } catch (error) {
        setErrors({ submit: error.message });
      } finally {
        setSubmitting(false);
      }
    },
  });

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Box sx={{ mb: 4, textAlign: 'center' }}>
        <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 700 }}>
          Create Your {role === 'provider' ? 'Provider' : 'Customer'} Account
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Join WorkerBee to {role === 'provider' ? 'offer your services' : 'find trusted professionals'}
        </Typography>
      </Box>

      <Box
        component="form"
        onSubmit={formik.handleSubmit}
        sx={{
          border: '1px solid #e0e0e0',
          borderRadius: 2,
          p: 4,
          boxShadow: 1,
        }}
      >
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="name"
              name="name"
              label="Full Name"
              value={formik.values.name}
              onChange={formik.handleChange}
              error={formik.touched.name && Boolean(formik.errors.name)}
              helperText={formik.touched.name && formik.errors.name}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              id="email"
              name="email"
              label="Email"
              value={formik.values.email}
              onChange={formik.handleChange}
              error={formik.touched.email && Boolean(formik.errors.email)}
              helperText={formik.touched.email && formik.errors.email}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              id="phone"
              name="phone"
              label="Phone Number"
              value={formik.values.phone}
              onChange={formik.handleChange}
              error={formik.touched.phone && Boolean(formik.errors.phone)}
              helperText={formik.touched.phone && formik.errors.phone}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              id="password"
              name="password"
              label="Password"
              type="password"
              value={formik.values.password}
              onChange={formik.handleChange}
              error={formik.touched.password && Boolean(formik.errors.password)}
              helperText={formik.touched.password && formik.errors.password}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              id="confirmPassword"
              name="confirmPassword"
              label="Confirm Password"
              type="password"
              value={formik.values.confirmPassword}
              onChange={formik.handleChange}
              error={formik.touched.confirmPassword && Boolean(formik.errors.confirmPassword)}
              helperText={formik.touched.confirmPassword && formik.errors.confirmPassword}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              select
              id="role"
              name="role"
              label="Role"
              value={formik.values.role}
              onChange={formik.handleChange}
            >
              <MenuItem value="customer">Customer</MenuItem>
              <MenuItem value="provider">Provider</MenuItem>
            </TextField>
          </Grid>

          {formik.values.role === 'provider' && (
            <>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  select
                  id="serviceType"
                  name="serviceType"
                  label="Service Type"
                  value={formik.values.serviceType}
                  onChange={formik.handleChange}
                  error={formik.touched.serviceType && Boolean(formik.errors.serviceType)}
                  helperText={formik.touched.serviceType && formik.errors.serviceType}
                >
                  {serviceTypes.map(service => (
                    <MenuItem key={service} value={service}>
                      {service}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>

              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  select
                  id="city"
                  name="city"
                  label="City"
                  value={formik.values.city}
                  onChange={formik.handleChange}
                  error={formik.touched.city && Boolean(formik.errors.city)}
                  helperText={formik.touched.city && formik.errors.city}
                >
                  {cities.map(city => (
                    <MenuItem key={city} value={city}>
                      {city}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>

              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  id="experience"
                  name="experience"
                  label="Experience (Years)"
                  type="number"
                  value={formik.values.experience}
                  onChange={formik.handleChange}
                  error={formik.touched.experience && Boolean(formik.errors.experience)}
                  helperText={formik.touched.experience && formik.errors.experience}
                />
              </Grid>
            </>
          )}

          <Grid item xs={12}>
            <Button
              fullWidth
              variant="contained"
              type="submit"
              disabled={formik.isSubmitting}
              sx={{ py: 1.5 }}
            >
              Register
            </Button>
          </Grid>

          <Box sx={{ textAlign: 'center', mt: 3, width: '100%' }}>
            <Typography variant="body2">
              Already have an account? <Link to="/login">Sign in</Link>
            </Typography>
          </Box>
        </Grid>
      </Box>
    </Container>
  );
};

export default Register;
