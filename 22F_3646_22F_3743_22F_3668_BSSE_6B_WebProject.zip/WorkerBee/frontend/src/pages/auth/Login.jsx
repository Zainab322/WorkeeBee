import React from 'react';
import { Box, Button, Container, TextField, Typography } from '@mui/material';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { GoogleLogin } from '@react-oauth/google';
import { Link } from 'react-router-dom';

const validationSchema = yup.object({
  email: yup.string().email('Enter a valid email').required('Email is required'),
  password: yup.string().required('Password is required'),
});

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();

  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
    },
    validationSchema: validationSchema,
    onSubmit: async (values, { setSubmitting, setErrors }) => {
      try {
        const result = await login(values);
if (result.success) {
          const role = result.user?.role;
          if (role === 'customer') {
            navigate('/customer/dashboard');
          } else if (role === 'provider') {
            navigate('/provider/dashboard');
          } else if (role === 'admin') {
            navigate('/admin/dashboard');
          } else {
            navigate('/');
          }
        } else {
          setErrors({ submit: result.message });
        }

      } catch (error) {
        setErrors({ submit: error.message });
      } finally {
        setSubmitting(false);
      }
    },
  });

  // Function to handle Google Sign-In
  const handleGoogleLogin = async (response) => {
    const { credential } = response;
    const userInfo = JSON.parse(atob(credential.split('.')[1]));
    console.log('User Info:', userInfo);

    // Store user info in localStorage (or send it to backend)
    localStorage.setItem('google_user', JSON.stringify({
      name: userInfo.name,
      email: userInfo.email,
      profilePicture: userInfo.picture,
    }));

    navigate('/');
  };

  return (
    <Container maxWidth="sm" sx={{ py: 8 }}>
      <Box sx={{ mb: 4, textAlign: 'center' }}>
        <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 700 }}>
          Welcome Back
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Sign in to your WorkerBee account
        </Typography>
      </Box>

      <Box
        component="form"
        onSubmit={formik.handleSubmit}
        sx={{
          border: '1px solid #e0e0e0',
          borderRadius: 2,
          p: 4,
          boxShadow: 1,
        }}
      >
        <TextField
          fullWidth
          id="email"
          name="email"
          label="Email"
          margin="normal"
          variant="outlined"
          value={formik.values.email}
          onChange={formik.handleChange}
          error={formik.touched.email && Boolean(formik.errors.email)}
          helperText={formik.touched.email && formik.errors.email}
        />
        <TextField
          fullWidth
          id="password"
          name="password"
          label="Password"
          type="password"
          margin="normal"
          variant="outlined"
          value={formik.values.password}
          onChange={formik.handleChange}
          error={formik.touched.password && Boolean(formik.errors.password)}
          helperText={formik.touched.password && formik.errors.password}
        />

        <Button
          fullWidth
          variant="contained"
          type="submit"
          disabled={formik.isSubmitting}
          sx={{ py: 1.5, mt: 1 }}
        >
          Sign In
        </Button>

        {/* Google Sign-In Button */}
        <GoogleLogin
          onSuccess={handleGoogleLogin}
          onError={(error) => console.log('Google Sign-In Error:', error)}
          useOneTap
        />

        <Box sx={{ textAlign: 'center', mt: 3 }}>
          <Typography variant="body2">
            Don't have an account? <Link to="/role-selection">Sign up</Link>
          </Typography>
        </Box>
      </Box>
    </Container>
  );
};

export default Login;
